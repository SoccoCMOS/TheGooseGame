import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.* ;
class MeilleurScore extends JDialog implements ActionListener,Serializable
{
	private static final int taille = 20;
	private transient JTable jTable2=new JTable();
    private transient JScrollPane jScrollPane1= new JScrollPane();
    private  Object[][] table= new Object[taille][2];
    private transient ArrayList<Joueur> jou=new ArrayList<Joueur>();
    private JLabel info=new JLabel(new ImageIcon("BestScores.png"));
    private JButton fermer=new JButton("Fermer");
    
    public MeilleurScore()
    {		
    	fermer.setCursor(new Cursor(12));

    	 fermer.addActionListener(this);

this.setModal(true);
Box ligne = Box.createVerticalBox () ;
this.setLayout (new BorderLayout (100, 20)) ; 
    	Joueur m;
    	ObjectOutputStream o = null;
    	ObjectInputStream kl;

    	boolean eof=false;
		try {
			 kl=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("BestScores.txt"))));
			 while(!eof){
				 try{
					m=(Joueur) kl.readObject();
			m=new Joueur(m.toString(),m.getBestScore());
			jou.add(m);
			 }
				 catch (EOFException e)
				 { eof = true ; // il passera a true lors d�une rencontre de fin de fichier
				 }
			 }
			

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			int i=0;

    	i=0;
    	Collections.sort(jou);
    	for(Joueur pl : jou)
    	{
    		table[i][0]=pl.toString();
    		table[i][1]=pl.getBestScore();
    		i++;	
    	}
    	this.add(ligne);
    	ligne.add(info);
    	fermer.setMinimumSize(new Dimension(150,30));
    	fermer.setMaximumSize(new Dimension(150,30));
    	fermer.setPreferredSize(new Dimension(150,30));
    	fermer.setIcon(new ImageIcon("Fermer.png"));
		jTable2.setModel(new javax.swing.table.DefaultTableModel(
	            table,
	            new String [] {
	                "Joueur", "Score"
	            }
	        ) {
	            Class[] types = new Class [] {
	                java.lang.String.class, java.lang.Integer.class
	            };
	            boolean[] canEdit = new boolean [] {
	                false, false
	            };

	            public Class getColumnClass(int columnIndex) {
	                return types [columnIndex];
	            }

	            public boolean isCellEditable(int rowIndex, int columnIndex) {
	                return canEdit [columnIndex];
	            }
	        });
	        jScrollPane1.setViewportView(jTable2);
	        if (jTable2.getColumnModel().getColumnCount() > 0) {
	            jTable2.getColumnModel().getColumn(0).setResizable(false);
	            jTable2.getColumnModel().getColumn(1).setResizable(false);
	        }
	      ligne.add(jScrollPane1);
	        this.add(fermer,BorderLayout.SOUTH);
			this.setBounds(500, 50, 431, 400);
	        this.setResizable(false);

    }
    public MeilleurScore(Joueur j)
    {
    	boolean trouv = false;
		fermer.setCursor(new Cursor(12));

 fermer.addActionListener(this);
this.setModal(true);
    	Box ligne = Box.createVerticalBox () ;
    	this.setLayout (new BorderLayout (100, 20)) ; 
    	    	Joueur m;
    	ObjectOutputStream o = null;
    	ObjectInputStream kl;

    	boolean eof=false;
		try {
			 kl=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("BestScores.txt"))));
			 while(!eof){
				 try{
					m=(Joueur) kl.readObject();
					
					m=new Joueur(m.toString(),m.getBestScore());
					if((m.toString()).equalsIgnoreCase(j.toString()))
					{
						trouv=true;

						if (m.getBestScore()<=j.getBestScore())
						{
							m=j;
						}
					}
					jou.add(m);}
				 catch (EOFException e)
				 { eof = true ; // il passera a true lors d�une rencontre de fin de fichier
				 }
			 }
			

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	if(!trouv){
		jou.add(j);
	}
			int i=0;
			try {
				o=new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File("BestScores.txt"))));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Joueur pl;
			Collections.sort(jou);
    	while(i<jou.size())
    	{

    		table[i][0]=jou.get(i).toString();
    		table[i][1]=jou.get(i).getBestScore();
    		pl=new Joueur((String)table[i][0],(int)table[i][1]);
    		i++;
    		
    		try {
				o.writeObject(pl);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	try {
			o.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	this.setBounds(800, 500, 431, 400);
    	this.add(ligne);
    	ligne.add(info);
    	fermer.setMinimumSize(new Dimension(150,30));
    	fermer.setMaximumSize(new Dimension(150,30));
    	fermer.setPreferredSize(new Dimension(150,30));
    	fermer.setIcon(new ImageIcon("Fermer.png"));

		jTable2.setModel(new javax.swing.table.DefaultTableModel(
	            table,
	            new String [] {
	                "               Joueur", "            Score"
	            }
	        ) {
	            Class[] types = new Class [] {
	                java.lang.String.class, java.lang.Integer.class
	            };
	            boolean[] canEdit = new boolean [] {
	                false, false
	            };

	            public Class getColumnClass(int columnIndex) {
	                return types [columnIndex];
	            }

	            public boolean isCellEditable(int rowIndex, int columnIndex) {
	                return canEdit [columnIndex];
	            }
	        });
	        jScrollPane1.setViewportView(jTable2);
	        if (jTable2.getColumnModel().getColumnCount() > 0) {
	            jTable2.getColumnModel().getColumn(0).setResizable(false);
	            jTable2.getColumnModel().getColumn(1).setResizable(false);
	        }
this.setResizable(false);
ligne.add(jScrollPane1);
	        this.add(fermer,BorderLayout.SOUTH);

    }   
    
    
    
    public void lectureScores()
    {
    	try {
			ObjectInputStream kl=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("BestScores.txt"))));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public String toString()
    {
    	return "";
    }
    
 
	@Override
	public void actionPerformed(ActionEvent ev) {
if(ev.getSource()==fermer){
	this.setVisible(false);
}
	}
}




public class BestScores {
	 public static void main (String args[])
	{ try {
	     UIManager.setLookAndFeel( "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
	}
	catch(Exception e){
	     System.out.println("Erreur de chargement de Nimbus !");
	}
		 MeilleurScore fen = new MeilleurScore(new Joueur("Mergaza",120)) ;
	}
	}