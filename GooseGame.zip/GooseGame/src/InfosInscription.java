

import java.awt.Image;

public class InfosInscription {  // Pour r�cup�rer les infos lors de l'inscription pour une nouvelle partie
	
	// Attributes
	private String pseudo;
	private Image avatar;
	
	// Constructors
	public InfosInscription()
	{
		this.pseudo="joueur";
		this.avatar=null;
	}
	// Getters and setters 
	
	public String getPseudo() {
		return pseudo;
	}
	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}
	public Image getAvatar() {
		return avatar;
	}
	public void setAvatar(Image avatar) {
		this.avatar = avatar;
	}
	
	// Methods

}
