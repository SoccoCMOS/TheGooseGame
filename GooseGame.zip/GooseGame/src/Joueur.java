import java.io.Serializable;


public class Joueur implements Serializable,Comparable{
private String pseudo;
private int bestScore;
public String toString()
{
	return this.pseudo;
}
public int getBestScore() {
	return bestScore;
}
public void setBestScore(int bestScore) {
	this.bestScore = bestScore;
}
public Joueur(String pseudo,int score)
{
	this.pseudo=pseudo;
	this.bestScore=score;
}
public Joueur()
{
	
}
public boolean equals(Joueur j)
{
	if (j.toString()==this.toString()){return true;}
	else{return false;}
}

public int compareTo(Object jou) {
	// TODO Auto-generated method stub
if (this.getBestScore()>((Joueur) jou).getBestScore()){return -1;}
else{
	if(this.getBestScore()==((Joueur)jou).getBestScore()){return 0;}
	else{
		return 1;
	}
	
}

}
}


