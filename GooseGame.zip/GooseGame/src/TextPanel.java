

import java.awt.*;

import javax.swing.*;

public class TextPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public TextPanel() {}
	
	public TextPanel(int height,int width)
	{
		super();
		this.setPreferredSize(new Dimension(height,width));
	}
	
	public TextPanel(int height, int width, String txt)
	{
		super();
		this.setPreferredSize(new Dimension(height,width));
		this.text=txt;
	}
	
	public TextPanel(int height, int width, String txt, int marginX, int marginY)
	{
		super();
		this.setPreferredSize(new Dimension(height,width));
		this.text=txt;
		this.marginX=marginX;
		this.marginY=marginY;
	}
	
	public void modifyText(String s)
	{
		this.setText(s);
		repaint();
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponents(g);
		g.drawString(text,marginX,marginY);
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public int getMarginX() {
		return marginX;
	}

	public void setMarginX(int marginX) {
		this.marginX = marginX;
	}

	public int getMarginY() {
		return marginY;
	}

	public void setMarginY(int marginY) {
		this.marginY = marginY;
	}

	private String text;
	private int marginX;
	private int marginY;

}
