import java.io.Serializable;


public class Depart extends Case implements Serializable{
	public Depart(Partie p) {
		super(p);
		// TODO Auto-generated constructor stub
	}

	public void traitement()
	{
		System.out.print("hhhhh");
	}
	public String toString()
	{
		return "Depart";
	}
}
