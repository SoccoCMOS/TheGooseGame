

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class WinPicture extends JDialog implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Partie p;
		
	public WinPicture() {
		this.setSize(new Dimension(500,450));
		this.setLocation(400, 100);
		this.setResizable(false);
		this.setTitle("Find The Right Picture");
		this.getContentPane().setBackground(Color.white);
	}
	public WinPicture (String s,ImageIcon im1, ImageIcon im2,ImageIcon im3,ImageIcon im4,int n,Partie p)
	{
		this.p=p;
		this.setSize(new Dimension(500,550));
		this.setLocation(400, 100);
		this.setResizable(false);
		this.setTitle("Find The Right Picture");
		this.getContentPane().setBackground(Color.white);
		this.word=s;
		this.im1=im1;
		this.im2=im2;
		this.im3=im3;
		this.im4=im4;
		this.imNumber=n;
		initComponent();
		
		pic1.addActionListener(this);
		pic2.addActionListener(this);
		pic3.addActionListener(this);
		pic4.addActionListener(this);
		pursue.addActionListener(this);
		
	}
	
	public void initComponent()
	{
	//1. Label d'information
		
		infos=new JLabel("FIND THE RIGHT PICTURE ! ",0);
		infos.setPreferredSize(new Dimension(400,50));
		infos.setMinimumSize(new Dimension(400,50));
		infos.setMaximumSize(new Dimension(400,50));
		
		infos.setLocation(10,10);
		infos.setForeground(Color.blue);
		infos.setFont(new Font("Hobo STD",4,24));
		
	//2. Panneau du mot 
		
		wordPan=new JPanel();
		wordPan.setPreferredSize(new Dimension(400,100));
		wordPan.setMinimumSize(new Dimension(400,100));
		wordPan.setMaximumSize(new Dimension(400,100));
		wordPan.setBackground(Color.white);
		wordPan.add(infos,BorderLayout.NORTH);
		
		
		// Ajout de la question
		
		wordLabel=new JLabel("Click on the picture that match the word : '" + word + "'",0);
		wordLabel.setPreferredSize(new Dimension(400,20));
		wordLabel.setMinimumSize(new Dimension(400,20));
		wordLabel.setMaximumSize(new Dimension(400,20));
		
		wordLabel.setLocation(10,10);
		wordLabel.setForeground(Color.black);
		wordLabel.setFont(new Font("Times New Roman",0,18));
		
		wordPan.add(wordLabel,BorderLayout.CENTER);
		
		this.getContentPane().add(wordPan,BorderLayout.NORTH);
		
	//3. Panneau occupant les images
		picArea=new JPanel();
		picArea.setLayout(new GridLayout(2,2,10,10));
		picArea.setBackground(Color.white);
		picArea.setPreferredSize(new Dimension(400,300));
		picArea.setMaximumSize(new Dimension(400,300));
		picArea.setMinimumSize(new Dimension(400,300));
		this.getContentPane().add(picArea,BorderLayout.CENTER);
		
		// Ajout des images
		pic1=new JButton();
		//pic1.setPreferredSize(new Dimension(200,120));
		//pic1.setMinimumSize(new Dimension(200,120));
		//pic1.setMaximumSize(new Dimension(200,120));
		pic1.setBackground(null);
		//pic1.setBorderPainted(false);
		pic1.setCursor(new Cursor(12));
		pic1.setIcon(im1);
		picArea.add(pic1);
		
		pic2=new JButton();
		//pic2.setPreferredSize(new Dimension(200,120));
		//pic2.setMinimumSize(new Dimension(200,120));
		//pic2.setMaximumSize(new Dimension(200,120));
		pic2.setBackground(null);
		pic2.setBorderPainted(false);
		pic2.setCursor(new Cursor(12));
		pic2.setIcon(im2);
		picArea.add(pic2);
		
		pic3=new JButton();
		//pic3.setPreferredSize(new Dimension(200,120));
		//pic3.setMinimumSize(new Dimension(200,120));
		//pic3.setMaximumSize(new Dimension(200,120));
		pic3.setBackground(null);
		pic3.setBorderPainted(false);
		pic3.setCursor(new Cursor(12));
		pic3.setIcon(im3);
		picArea.add(pic3);
		
		pic4=new JButton();
		//pic4.setPreferredSize(new Dimension(200,120));
		//pic4.setMinimumSize(new Dimension(200,120));
		//pic4.setMaximumSize(new Dimension(200,120));
		pic4.setBackground(null);
		pic4.setBorderPainted(false);
		pic4.setCursor(new Cursor(12));
		pic4.setIcon(im4);
		picArea.add(pic4);
		
	//4. Panneau d'appr�ciation
		apprecPanel=new JPanel();
		apprecPanel.setBackground(Color.white);
		apprecPanel.setPreferredSize(new Dimension(400,60));
		apprecPanel.setMaximumSize(new Dimension(400,60));
		apprecPanel.setMinimumSize(new Dimension(400,60));		
		this.getContentPane().add(apprecPanel,BorderLayout.SOUTH);
		
		// Ajout de l'appr�ciation
		
		appreciation=new JLabel("");
		appreciation.setHorizontalAlignment(JLabel.CENTER);
		appreciation.setVerticalAlignment(JLabel.CENTER);
		appreciation.setForeground(Color.red);
		appreciation.setFont(new Font("Times New Roman",1,18));
		
		apprecPanel.add(appreciation,BorderLayout.CENTER);
		
		// Ajout du bouton de poursuite (retour vers le plateau)
		pursue=new JButton("Back To Plate");
		apprecPanel.add(pursue,BorderLayout.SOUTH);
		pursue.setVisible(false);
	}
	
	// Getters & setters
	
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	
	
	public boolean isCorrect() {
		return isCorrect;
	}
	public void setCorrect(boolean isCorrect) {
		this.isCorrect = isCorrect;
	}


	//Attributes
	private int imNumber;
	private String word;
	private JLabel infos;
	private JPanel wordPan;
	private JLabel wordLabel;
	private JPanel picArea;
	private JPanel apprecPanel;
	private JLabel appreciation;
	private JButton pic1,pic2,pic3,pic4;
	private ImageIcon im1,im2,im3,im4;
	private JButton pursue;
	private boolean isCorrect=false;
	
	
	// GESTION DES EVENEMENTS
	
	public void actionPerformed(ActionEvent ev)
	{
		if (ev.getSource()==pic1)
		{
			if (imNumber==1)
			{
				appreciation.setForeground(Color.green);

				appreciation.setText("Right Answer ! ");
				Thread music=new MusiqueFond("Sons/CorrectAnswer.wav",0);
				music.start();
				pic2.setEnabled(false);
				pic3.setEnabled(false);
				pic4.setEnabled(false);
				isCorrect=true;
				p.setCaseActu(p.getCaseActu()+2);
				p.setScoreEnCours(p.getScoreEnCours()+10);
			}
			else 
			{
				appreciation.setForeground(Color.red);

				appreciation.setText("Wrong Answer ! ");
				Thread music=new MusiqueFond("Sons/BadAnswer.wav",0);
				music.start();
				//pic1.setEnabled(false);
				pic2.setEnabled(false);
				pic3.setEnabled(false);
				pic4.setEnabled(false);
				isCorrect=false;
			}
			pursue.setVisible(true);
		}
		else if (ev.getSource()==pic2)
		{
			if (imNumber==2)
			{
				appreciation.setForeground(Color.green);

				appreciation.setText("Right Answer ! ");
				Thread music=new MusiqueFond("Sons/CorrectAnswer.wav",0);
				music.start();
				pic1.setEnabled(false);
				pic3.setEnabled(false);
				pic4.setEnabled(false);
				isCorrect=true;
				p.setCaseActu(p.getCaseActu()+2);
				p.setScoreEnCours(p.getScoreEnCours()+10);
			}
			else 
			{
				appreciation.setForeground(Color.red);

				appreciation.setText("Wrong Answer ! ");
				Thread music=new MusiqueFond("Sons/BadAnswer.wav",0);
				music.start();
				pic1.setEnabled(false);
				pic3.setEnabled(false);
				pic4.setEnabled(false);
				isCorrect=false;
			}
			pursue.setVisible(true);
			
		} else if (ev.getSource()==pic3)
		{
			if (imNumber==3)
			{
				appreciation.setForeground(Color.green);

				appreciation.setText("Right Answer ! ");
				Thread music=new MusiqueFond("Sons/CorrectAnswer.wav",0);
				music.start();
				pic1.setEnabled(false);
				pic2.setEnabled(false);
				pic4.setEnabled(false);
				isCorrect=true;
				p.setCaseActu(p.getCaseActu()+2);
				p.setScoreEnCours(p.getScoreEnCours()+10);
			}
			else 
			{
				appreciation.setForeground(Color.red);

				appreciation.setText("Wrong Answer !");
				Thread music=new MusiqueFond("Sons/BadAnswer.wav",0);
				music.start();
				pic1.setEnabled(false);
				pic2.setEnabled(false);
				pic4.setEnabled(false);
				isCorrect=false;
			}
			pursue.setVisible(true);
			
		} else if (ev.getSource()==pic4)
		{
			if (imNumber==4)
			{
				appreciation.setForeground(Color.green);

				appreciation.setText("Right Answer ! ");
				Thread music=new MusiqueFond("Sons/CorrectAnswer.wav",0);
				music.start();
				pic1.setEnabled(false);
				pic2.setEnabled(false);
				pic3.setEnabled(false);
				isCorrect=true;
				p.setCaseActu(p.getCaseActu()+2);
				p.setScoreEnCours(p.getScoreEnCours()+10);
			}
			else 
			{
				appreciation.setForeground(Color.red);

				appreciation.setText("Wrong Answer Answer !");
				Thread music=new MusiqueFond("Sons/BadAnswer.wav",0);
				music.start();
				pic1.setEnabled(false);
				pic2.setEnabled(false);
				pic3.setEnabled(false);
				isCorrect=false;
			}
			pursue.setVisible(true);
		}
		else 
		{
			this.setVisible(false);
		}
			
	}
}
