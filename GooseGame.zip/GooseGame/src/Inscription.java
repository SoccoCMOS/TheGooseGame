
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

@SuppressWarnings("serial")

public class Inscription extends JDialog implements ActionListener, KeyListener{

/// Attributes

	private InfosInscription infos;
	private boolean sendData;

	private JLabel infosAvatar,infosPseudo;
	private JTextField saisiePseudo;
	private JButton valider,annuler;
	@SuppressWarnings("unchecked")
	private JComboBox choixAvatar; 
	private int sensPlateau=1;
	private PanAvatar canvas;
	private Fen2 fen2;
	private boolean cancel;
	

/// Setters and Getters
	
public boolean getSendData() {
	return sendData;
}

public void setSendData(boolean sendData) {
	this.sendData = sendData;
}

public int getSensPlateau() {
	return sensPlateau;
}

public void setSensPlateau(int sensPlateau) {
	this.sensPlateau = sensPlateau;
} 

public InfosInscription getInfos() {
	return infos;
}

public void setInfos(InfosInscription infos) {
	this.infos = infos;
}

public JLabel getInfosAvatar() {
	return infosAvatar;
}

public void setInfosAvatar(JLabel infosAvatar) {
	this.infosAvatar = infosAvatar;
}

public JLabel getInfosPseudo() {
	return infosPseudo;
}

public void setInfosPseudo(JLabel infosPseudo) {
	this.infosPseudo = infosPseudo;
}

public JTextField getSaisiePseudo() {
	return saisiePseudo;
}

public void setSaisiePseudo(JTextField saisiePseudo) {
	this.saisiePseudo = saisiePseudo;
}

public JButton getValider() {
	return valider;
}

public void setValider(JButton valider) {
	this.valider = valider;
}

public JButton getAnnuler() {
	return annuler;
}

public void setAnnuler(JButton annuler) {
	this.annuler = annuler;
}

public JComboBox getChoixAvatar() {
	return choixAvatar;
}

public void setChoixAvatar(JComboBox choixAvatar) {
	this.choixAvatar = choixAvatar;
}

public PanAvatar getCanvas() {
	return canvas;
}

public void setCanvas(PanAvatar canvas) {
	this.canvas = canvas;
}

public Fen2 getFen2() {
	return fen2;
}

public void setFen2(Fen2 fen2) {
	this.fen2 = fen2;
}



/// Constructor
public Inscription()
	{
	// Instanciation de la boite de dialogue
		super((JFrame)null,"Nouvelle Partie");
		setSendData(false);
	
		infos= new InfosInscription();
/// Param�trisation
		
	    //On sp�cifie une taille
	    this.setSize(300, 300);
	    
	    //Gestionnaire de mise en forme
	    /// Par defaut
	    
	    //La position
	    this.setLocationRelativeTo(null);
	    
	    //La bo�te ne devra pas �tre redimensionnable
	    this.setResizable(false);
	    this.setDefaultCloseOperation(HIDE_ON_CLOSE);

	    // Bouton valider d�sactiv� jusqu'� la saisie d'un caract�re
	    
/// Ajouts des composants 	    
	    this.initComponent();
	
/// Ev�nements li�s aux objets 
	    
	 saisiePseudo.addActionListener(this);
	 saisiePseudo.addKeyListener(this);
	 choixAvatar.addActionListener(this);
	 valider.addActionListener(this);
	 annuler.addActionListener(this);
	}

@SuppressWarnings("unchecked")
private void initComponent()
{
	// Saisie Pseudo
	
    JPanel panNom = new JPanel();
    panNom.setBackground(Color.white);
    panNom.setPreferredSize(new Dimension(300, 60));
    saisiePseudo = new JTextField();
    saisiePseudo.setPreferredSize(new Dimension(100, 25));
    panNom.setBorder(BorderFactory.createTitledBorder("Votre pseudo"));
    infosAvatar = new JLabel("Saisir un nom :");
    panNom.add(infosAvatar);
    panNom.add(saisiePseudo);
    
    // Ajout Avatar 
    JPanel panAvatar = new JPanel();
    panAvatar.setBackground(Color.white);
    panAvatar.setPreferredSize(new Dimension(300,140));
    panAvatar.setBorder(BorderFactory.createTitledBorder("Votre CROAQ-Avatar"));
    canvas=new PanAvatar();
    canvas.setAvatar("avatars/18.png");
    panAvatar.add(canvas);
    
    //canvas.paintIcon(panAvatar, getGraphics(),5,5);
    
   
    // Ajout menu des choix 
    choixAvatar=new JComboBox();
    choixAvatar.setEditable(false);
    choixAvatar.setPreferredSize(new Dimension(150,20));
    choixAvatar.addItem("(Default)");
    choixAvatar.addItem("Cool Man");
    choixAvatar.addItem("Black");
    choixAvatar.addItem("Happy Man");
    choixAvatar.addItem("Girl");
    choixAvatar.addItem("Little Girl");
    choixAvatar.addItem("Blond girl");
    choixAvatar.addItem("Captain America");
    choixAvatar.addItem("Red head girl");
    choixAvatar.addItem("Hulk");
    choixAvatar.addItem("Thor");
    choixAvatar.addItem("Antenna");
    choixAvatar.addItem("Iron-Man");
    choixAvatar.addItem("Anouche");
    choixAvatar.addItem("Cow-Boy");
    choixAvatar.addItem("Geekette");
    choixAvatar.addItem("Sydney");
    choixAvatar.addItem("Classic");
    choixAvatar.addItem("Chauve");
    choixAvatar.addItem("Bald");
    choixAvatar.addItem("Engineer");
    choixAvatar.addItem("Homme");
    choixAvatar.addItem("Batman");
    choixAvatar.addItem("Spiderman");
    choixAvatar.addItem("Spider Minus");
    choixAvatar.addItem("Catwoman");
    choixAvatar.addItem("Superman");
    
    //choixAvatar.setBackground(Color.white);
    
    // Ajout des choix 

    panAvatar.add(canvas,BorderLayout.WEST);
    panAvatar.add(choixAvatar,BorderLayout.EAST);
    

    // Ajout boutons de validation
    JPanel controlPan=new JPanel();
    controlPan.setBackground(Color.white);
    controlPan.setPreferredSize(new Dimension(300,80));
    controlPan.setBorder(BorderFactory.createTitledBorder("Valider vos informations"));
    
    valider=new JButton("Commencer");
    valider.setPreferredSize(new Dimension(110,30));
    valider.setBorderPainted(false);
    valider.setBackground(Color.orange);
    valider.setMargin(new Insets(5,5,5,5));
    //valider.setEnabled(false);
    
    annuler=new JButton("Annuler");
    annuler.setPreferredSize(new Dimension(80,30));
    annuler.setBorderPainted(false);
    annuler.setBackground(Color.orange);
    annuler.setMargin(new Insets(5,5,5,5));
    controlPan.add(valider);
    controlPan.add(annuler);
    
    // Ajout � la fenetre principale
    
   this.add(panNom,BorderLayout.NORTH);
   this.add(panAvatar,BorderLayout.WEST);
   this.add(controlPan,BorderLayout.SOUTH);
   
}

//M�thodes �couteurs


public void actionPerformed(ActionEvent arg) {
	
	if(arg.getSource()==saisiePseudo)
	{
		/**	if (!saisiePseudo.getText().isEmpty())
		{
			valider.setEnabled(true);
			trtSaisiePseudo();
		}
		else
		{
			valider.setEnabled(false);
		} **/
//		trtSaisiePseudo();
	}
	else if (arg.getSource()==choixAvatar)
	{
		trtAvatar();
	}
	else if (arg.getSource()==valider)
	{
		trtValider();
	}
	else
	{
		trtAnnuler();
	}
	
}

private void trtAnnuler() {
	
	this.setVisible(false);
	Menu men=new Menu();
	men.setVisible(true);
	cancel=false;
}

private void trtValider() {
	Pattern p = Pattern.compile("[^a-zA-Z0-9 - ---]");
	boolean hasSpecialChar = p.matcher(saisiePseudo.getText()).find();
	if(!hasSpecialChar){
	String filename;
	filename="avtars"+"/a"+(canvas.getAvatar()).substring((canvas.getAvatar()).indexOf("/")+1,(canvas.getAvatar()).length());
	trtSaisiePseudo();
	infos.setAvatar(canvas.im);
	this.setVisible(false);
	String orientation[]={"Bas Droit","Bas Gauche","Haut Droit","Haut Gauche"};
	//String txt = (String)JOptionPane.showInputDialog (this,"Choisissez le coin de d�part de la spirale", "Chargement du plateau",JOptionPane.QUESTION_MESSAGE, null,orientation, orientation[1]) ;
	if(!cancel){
	String txt = (String)JOptionPane.showInputDialog (this,"Choisissez le coin de d�part de la spirale", "Chargement du plateau",0,new ImageIcon("spir.png"),orientation, orientation[0]) ;
	if(txt!=null){
	
	if (txt=="Bas Droit")
	{
		fen2=new Fen2(filename,saisiePseudo.getText(),1);

	}
	else if (txt=="Bas Gauche")
	{
		fen2=new Fen2(filename,saisiePseudo.getText(),2);
		
	} else if (txt=="Haut droit")
	{
		fen2=new Fen2(filename,saisiePseudo.getText(),3);
		
	} else 
	{
		fen2=new Fen2(filename,saisiePseudo.getText(),4);
	}
	fen2.setVisible(true);
//	Thread music=new MusiqueFond("Sons/Applaude.wav",0);
//	music.start();
	}
	else{
		Menu men=new Menu();
		men.setVisible(true);
	}}}
	else{
		JOptionPane.showMessageDialog(null, "Enlevez les caract�res sp�ciaux","Erreur",JOptionPane.ERROR_MESSAGE);

	}
	
}

private void trtAvatar() {
	int choix=choixAvatar.getSelectedIndex();
	switch (choix) 
	{
	case 1 :
	{
		canvas.setAvatar("avatars/0.png");
		break;
	}
	case 2 :
	{
		canvas.setAvatar("avatars/1.png");
		break;
	}
	case 3 :
	{
		canvas.setAvatar("avatars/2.png");
		break;
	}
	case 4 :
	{
		canvas.setAvatar("avatars/3.png");
		break;
	}
	case 5 :
	{
		canvas.setAvatar("avatars/4.png");
		break;
	}
	case 6 :
	{
		canvas.setAvatar("avatars/5.png");
		break;
	}
	case 7 :
	{
		canvas.setAvatar("avatars/6.png");
		break;
	}
	
	case 8 :
	{
		canvas.setAvatar("avatars/7.png");
		break;
	}
	
	case 9 :
	{
		canvas.setAvatar("avatars/8.png");
		break;
	}
	case 10 :
	{
		canvas.setAvatar("avatars/9.png");
		break;
	}
	case 11 :
	{
		canvas.setAvatar("avatars/10.png");
		break;
	}
	case 12 :
	{
		canvas.setAvatar("avatars/11.png");
		break;
	}
	case 13 :
	{
		canvas.setAvatar("avatars/12.png");
		break;
	}
	case 14 :
	{
		canvas.setAvatar("avatars/13.png");
		break;
	}
	case 15 :
	{
		canvas.setAvatar("avatars/14.png");
		break;
	}
	case 16 :
	{
		canvas.setAvatar("avatars/15.jpg");
		break;
	}
	case 17 :
	{
		canvas.setAvatar("avatars/16.png");
		break;
	}
	case 18 :
	{
		canvas.setAvatar("avatars/17.png");
		break;
	}
	case 19 :
	{
		canvas.setAvatar("avatars/18.jpg");
		break;
	}
	case 20 :
	{
		canvas.setAvatar("avatars/19.jpg");
		break;
	}
	
	case 21 :
	{
		canvas.setAvatar("avatars/20.png");
		break;
	}
	case 22 :
	{
		canvas.setAvatar("avatars/21.png");
		break;
	}
	case 23 :
	{
		canvas.setAvatar("avatars/22.png");
		break;
	}
	case 24 :
	{
		canvas.setAvatar("avatars/23.png");
		break;
	}
	case 25 :
	{
		canvas.setAvatar("avatars/24.png");
		break;
	}
	
	case 26 :
	{
		canvas.setAvatar("avatars/25.png");
		break;
	}
	default :
	{
		canvas.setAvatar("avatars/18.png");
		break;
	}
	}
	 
}

private void trtSaisiePseudo() 
{
		infos.setPseudo(saisiePseudo.getText());			
}

public void keyPressed(KeyEvent ev) {
	// TODO Auto-generated method stub
	valider.setEnabled(true);
}

public void keyReleased(KeyEvent ev) {
	// TODO Auto-generated method stub
	
}

public void keyTyped(KeyEvent ev) {
	// TODO Auto-generated method stub
	
}

public boolean isCancel() {
	return cancel;
}

public void setCancel(boolean cancel) {
	this.cancel = cancel;
}


}







