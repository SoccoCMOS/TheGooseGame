	

	import java.io.File;

	public class ImageFilter extends javax.swing.filechooser.FileFilter
	{
		// M�thode abstraite h�rit�e "accept"
		
		public boolean accept(File f) {
			return f.getName().toLowerCase().endsWith(".png")|| f.isDirectory();	
		}
		
	    public String getDescription() {
	        return "Image PNG";
	      }
	}


