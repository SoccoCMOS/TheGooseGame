import java.io.Serializable;


public class Bonus extends Case implements Serializable{
	public void traitement()
	{
P.setCaseActu(P.getCaseActu()+3);
P.setScoreEnCours(P.getScoreEnCours()+10);

}
	public Bonus(Partie p)
	{
		super(p);
	}
	
	public String toString(){
	
		return "Bonus";
	}
		
	
}
