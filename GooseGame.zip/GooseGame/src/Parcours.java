import java.io.Serializable;


public class Parcours implements Serializable{
	public void traitement()
	{
		System.out.println("Parcours");
	}
	
	public String toString()
	{
		return "Parcours";
	}
}
