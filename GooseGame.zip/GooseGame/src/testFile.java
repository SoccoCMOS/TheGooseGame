//Package � importer afin d'utiliser l'objet File
import java.io.File;
public class testFile {
public static void main(String[] args) {
//Cr�ation de l'objet File
File f = new File("test.txt");
File f2=new File("D:\\exo1\\Images");
System.out.println("Chemin absolu du fichier : " +
f.getAbsolutePath());
String mot=new String("hohohoh.png");
System.out.println(mot.indexOf(".jpg"));

for(File file : f2.listFiles())
{
System.out.println((file.getName()).substring(0, (file.getName()).indexOf(".png")));
try {
int i = 1;
//On parcourt la liste des fichiers et r�pertoires
for(File nom : file.listFiles()){
//S'il s'agit d'un dossier, on ajoute un "/"
//
System.out.print("\t\t"+nom.getName()+("hohoh.png").indexOf(".png"));
if((i%4) == 0){
System.out.print("\n");
}
i++;
}
System.out.println("\n");
} catch (NullPointerException e) {
//L'instruction peut g�n�rer une NullPointerException
//s'il n'y a pas de sous-fichier !
}
}
}
}