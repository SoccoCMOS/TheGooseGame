package swing.tests;
 
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;
 
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
 
public class AnimatedRectangle extends JPanel {
 
 
    private Rectangle2D rect;
    private Timer timer;
 private  Container contenu;
    public AnimatedRectangle() {  
    	 JButton b;
    	  contenu =this;
        rect = new Rectangle2D.Float(20,20,100,100);
        timer = new Timer(100,new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
            	JButton b;
                System.out.println("hello width: "+rect.getWidth());
                if(rect.getWidth()> 0) {
 b=new JButton();
 contenu.add(b);
                    rect.setRect(rect.getBounds2D().getX()+1, rect.getBounds2D().getY()+1, rect.getBounds2D().getWidth()-2, rect.getBounds2D().getHeight()-2) ;
                } else {
                    timer.stop();
                }                
                repaint();
            }
        });
        timer.start();
    }
 
    @Override
    protected void paintComponent(Graphics arg0) {    
        super.paintComponent(arg0);
        System.out.println(rect);
        Graphics2D g2d = (Graphics2D) arg0;
        g2d.setPaint(Color.red);
        g2d.fill(rect);
 
    }
 
    public static void main(String[] args) {
        JFrame f = new JFrame();
        f.add(new AnimatedRectangle());
        f.setSize(400,300);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setVisible(true);
    }
}