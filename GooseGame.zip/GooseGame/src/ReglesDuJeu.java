

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

public class ReglesDuJeu extends JDialog implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ReglesDuJeu() 
	{
		this.setModal(true);
		this.setSize(new Dimension(760,500));
		this.setResizable(false);
		this.setTitle("How To Play");
		this.setIconImage((new ImageIcon("pioupiou.png")).getImage());
		this.setLocation(400,200);
		this.getContentPane().setBackground(Color.white);		
		
		initComponent();
		back.addActionListener(this);
	}
	
	
	public void initComponent()
	{
		
		// Label d'infos
		/**
		infosWindow=new JLabel("R�gles du Jeu",0);
		infosWindow.setPreferredSize(new Dimension(400,50));
		infosWindow.setMinimumSize(new Dimension(400,50));
		infosWindow.setMaximumSize(new Dimension(400,50));
		
		infosWindow.setLocation(10,10);
		infosWindow.setForeground(Color.getHSBColor(57,80,120));
		infosWindow.setFont(new Font("Hobo STD",4,28)); **/
		
		// Ajout � la fenetre
		//this.getContentPane().add(infosWindow,BorderLayout.NORTH);
		
		// Panel o� mettre les r�gles du jeu
		
		regles=new JPanel();

		//regles.setBorder(BorderFactory.createTitledBorder(new TitledBorder(""),"R�gles du jeu",0,0,new Font("Times New Roman",1,28),Color.getHSBColor(57,80,120)));
		regles.setBorder(BorderFactory.createTitledBorder(new TitledBorder(""),"R�gles du jeu",0,0,new Font("Times New Roman",1,28),Color.orange));
		regles.setPreferredSize(new Dimension(400,400));
		regles.setBackground(Color.white);
		
		// Cr�er le JScrollPane qui va contenir le panel pr�c�dent
		
		body=new JScrollPane(regles);
		body.setPreferredSize(new Dimension(500,300));
		body.setMinimumSize(new Dimension(500,300));
		body.setMaximumSize(new Dimension(500,300));
		body.setBorder(null);

		
		// Ajout du corps � la fenetre
		
		this.getContentPane().add(body,BorderLayout.CENTER);
		
		// Ajout du bouton retour au plateau
		
		JPanel backPan=new JPanel();
		backPan.setLayout(new FlowLayout());
		backPan.setBackground(Color.white);
		back= new JButton("Back To Menu");
		back.setPreferredSize(new Dimension(150,30));
		back.setMinimumSize(new Dimension(150,30));
		back.setMaximumSize(new Dimension(150,30));
		back.setBackground(Color.orange);
        body.setViewportView(aide);

		backPan.add(back);
		this.getContentPane().add(backPan,BorderLayout.SOUTH);
	}


// Attributes
private JScrollPane body;
private JPanel regles;
//private JLabel infosWindow;
private JButton back;
private JLabel aide=new JLabel(new ImageIcon("Aide.png"));
public void actionPerformed(ActionEvent ev) {
	
	this.setVisible(false);
}

public static void main(String args[])
{
	try {
	     UIManager.setLookAndFeel( "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
	}
	catch(Exception e){
	     System.out.println("Erreur de chargement de Nimbus !");
	}
	ReglesDuJeu r=new ReglesDuJeu();
	r.setVisible(true);
}
}
