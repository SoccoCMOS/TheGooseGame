import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

import javax.swing.*;
public class GameOver extends JDialog implements ActionListener{
private JLabel finPartie=new JLabel(new ImageIcon("Bravo.png"));
private JLabel Score =new JLabel ("Score : ");
private JLabel mScore =new JLabel("Meilleurs Score :");
private JLabel record=new JLabel("Record di jeu");
private JLabel detenu=new JLabel("Detenu par :");
private JButton afficher=new JButton("Meilleurs Scores ");
private JButton recommencer=new JButton("Recommencer");
private JButton menu=new JButton("Revenir au menu");
private JButton quitter=new JButton("Quitter le jeu");
private JLabel ima=new JLabel(new ImageIcon("player.walk.gif"));
private Fen2 f;
private Joueur player;
private String path;



public GameOver(Joueur j,int score,Fen2 ff)
{
	this.setModal(true);
	MeilleurScore z=new MeilleurScore(j);
this.setBackground(Color.white);
	this.path=path;
	this.player=j;
	this.f=ff;
	this.setResizable(false);
	this.setBounds(200, 50, 700, 390);
	this.setLayout(new BorderLayout(20,20));
	Box ligne = Box.createVerticalBox () ;
	Box colonne = Box.createHorizontalBox () ;
	Joueur best = new Joueur();
    ligne.setBorder(BorderFactory.createTitledBorder("Informations"));
    colonne.setBorder(BorderFactory.createTitledBorder("Fin Partie"));

ligne.setBackground(Color.orange);
	this.add(ligne);
	Score.setText("Score : "+score);
	mScore.setText("Meilleurs score : \n"+j.getBestScore());
	ObjectInputStream kl = null;
	try {
		kl=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("BestScores.txt"))));
		try {
			best=(Joueur)kl.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	if(best.getBestScore()>j.getBestScore()){
	record.setText("Record du jeu : "+best.getBestScore());
	detenu.setText("Detenu par : "+best.toString());}
	else{
		record.setText("Record du jeu : "+j.getBestScore());
		detenu.setText("Detenu par : "+j.toString());	
	}

	this.add(finPartie,BorderLayout.NORTH);
	ligne.add(ima);
	ligne.add(Score);
	ligne.add(mScore);
	ligne.add(record);
	ligne.add(detenu);
	colonne.add(recommencer);
	colonne.add(menu);
	colonne.add(quitter);
	ligne.add(afficher);
	this.add(colonne,BorderLayout.BEFORE_LINE_BEGINS);
	recommencer.addActionListener(this);
	menu.addActionListener(this);
	quitter.addActionListener(this);
	afficher.addActionListener(this);
	recommencer.setIcon(new ImageIcon("again.png"));
	quitter.setIcon(new ImageIcon("exit (2).png"));
	afficher.setIcon(new ImageIcon("medal.png"));
	menu.setIcon(new ImageIcon("back2.png"));
	afficher.setBackground(Color.orange);
	quitter.setBackground(Color.orange);
	recommencer.setBackground(Color.orange);
	menu.setBackground(Color.orange);
	menu.setCursor(new Cursor(12));
	recommencer.setCursor(new Cursor(12));
	quitter.setCursor(new Cursor(12));
	afficher.setCursor(new Cursor(12));
	this.setVisible(true);
	MeilleurScore bst=new MeilleurScore(player);	
}
	public static void main(String[] args) {
		try {
		     UIManager.setLookAndFeel( "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		}
		catch(Exception e){
		     System.out.println("Erreur de chargement de Nimbus !");
		}

	}

	@Override
	public void actionPerformed(ActionEvent ev) {
if(ev.getSource()==recommencer)
{
	this.setModal(false);
f.setVisible(false);
this.setVisible(false);
f=new Fen2("avatars\\a2.jpg",player.toString(),1);
f.setVisible(true);
}
if(ev.getSource()==quitter){
	this.setModal(false);
	f.setVisible(false);
	this.setVisible(false);
}
if(ev.getSource()==menu)
{
	this.setModal(false);
	f.setVisible(false);
	this.setVisible(false);
	Menu men=new Menu();
	men.setVisible(true);
}
if(ev.getSource()==afficher){
	this.setModal(false);
	MeilleurScore best=new MeilleurScore();
	best.setVisible(true);
	
}
	}

}
