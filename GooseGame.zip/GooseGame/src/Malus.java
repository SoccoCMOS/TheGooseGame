import java.io.Serializable;


public class Malus extends Case implements Serializable{
	public Malus(Partie p) {
		super(p);
		// TODO Auto-generated constructor stub
	}

	public void traitement()
	{
		P.setCaseActu(P.getCaseActu()-2);
		if(P.getScoreEnCours()-10>=0){
		P.setScoreEnCours(P.getScoreEnCours()-10);}
		}
	
	public String toString()
	{
		return "Malus";
	}

}
