import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;


public class Musique extends Thread {
	
	private AudioClip ac;
	public Musique(String s)
	{
		URL url = Musique.class.getResource("Sons/Applaude.wav");
		AudioClip ac = Applet.newAudioClip(url);
		
	}
	
	public void run()
	{
		ac.play();
	}

}
