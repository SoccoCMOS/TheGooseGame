

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class PanAvatar extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Image im;
	private String avatar;
	
	// Setter & Getter 
	public Image getIm() {
		return im;
	}
	public void setIm(Image im) {
		this.im = im;
	}
	
	
	public PanAvatar() 
	{
	    setBackground(Color.cyan);
	    setPreferredSize(new Dimension(100,100));
	}
	public void setAvatar(String s)
	{
	    ImageIcon icon=new ImageIcon(s);
	    im=icon.getImage();
	    repaint();
	    this.avatar=s;
	    
	}
	
	public String getAvatar()
	{
		return this.avatar;
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage(im,0,0,this);
		
	}
}
