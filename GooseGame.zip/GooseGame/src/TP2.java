import javax.swing.* ;
import java.awt.* ;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.JOptionPane;


//Renommer les premi�res classes

 class ImagePanel extends JPanel {
	 
    private static final long serialVersionUID = 1L;
 
    /**
     * @param args
     */
  
    private Image img;
     
    public ImagePanel(Image img){
        this.img = img;
        
    }
     
    public void paintComponent(Graphics g) {
        g.drawImage(img, 0, 0, null);
    }
}
class Menup extends JFrame implements ActionListener
{
	private JButton comm=new JButton("Commencer");
	private JButton rep=new JButton("Reprendre");
	private JLabel i=new JLabel(new ImageIcon("as.gif"));
	private Fen2 fen;
	private Inscription inscription;
	
	public Menup()
	{
		this.fen=fen;
		this.setSize(300, 300);
		this.setLayout(new FlowLayout());
		this.add(comm);
		this.add(i);
		this.setVisible(true);
		comm.addActionListener(this);
		rep.addActionListener(this);
		this.add(rep);
	        this.setSize(new Dimension(600,400));
	}
	
	
public void actionPerformed(ActionEvent ev) {
	String Filename;
	ObjectInputStream i;
	if(ev.getSource() == comm){
		inscription=new Inscription();
		inscription.setVisible(true);

//	this.setVisible(false);
	}
	if(ev.getSource() == rep)
	{
		try {
			Filename=ExitDialog.saveActions(true);
			i=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File(Filename))));
			Partie pp;
			pp=(Partie)i.readObject();
			for (int j=0;j<=99;j++)
			{
				if(pp.getCase(j)!=null){
					pp.setCasep(pp,j);
					
				}
			}
			fen=new Fen2(pp);
			fen.setVisible(true);

		} catch ( IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	}

}
class Fen2 extends JFrame
{
	
	private JPanel pan;
	private JPanel infoJeu;
	private JPanel infoJoueur;
	private JPanel BarreAction;
	private JLabel Titre=new JLabel(new ImageIcon("petitLogo.png"));

	public Fen2(String path,String name,int dir){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// R�glage des dimensions
		
	Toolkit tk = Toolkit.getDefaultToolkit() ;
	Dimension dimEcran = tk.getScreenSize() ;
	this.setBounds(0, 0,dimEcran.width, dimEcran.height);
	this.setResizable(false);
	this.getContentPane().setBackground(Color.white);
	GridBagLayout g = new GridBagLayout();
	this.setLayout(g);
	GridBagConstraints c = new GridBagConstraints() ;
	c.fill = GridBagConstraints.BOTH ;
	infoJeu= new infoJeu();
	infoJoueur= new infoJoueur();
	pan=new Plateau(dir,(infoJeu)infoJeu,name,(infoJoueur)infoJoueur,path,this);
	
	BarreAction= new BarreAction((Plateau)pan,this);

	c.gridx = 0 ; c.gridy = 0 ;
	c.gridwidth = 1 ; c.gridheight = 1 ;
	c.weightx = 1 ; c.weighty = 1 ;
	this.add(infoJeu,c);

	c.gridx = 1 ; c.gridy = 0 ;
	c.gridwidth = 1 ; c.gridheight = 2 ;
	c.weightx = 1 ; c.weighty = 1 ;
	this.add(Titre,c);
	Titre.setToolTipText("Jeu d'Apprentissage de l'anglais");
	
	c.gridx = 2 ; c.gridy = 0 ;
	c.gridwidth = 1 ; c.gridheight = 2 ;
	c.weightx = 1 ; c.weighty = 1 ;
	this.add(infoJoueur,c);
	
	c.gridx = 0 ; c.gridy = 30;
	c.gridwidth = 1 ; c.gridheight = 1 ;
	c.weightx = 1 ; c.weighty = 1 ;
	this.add(BarreAction,c);
	
	c.gridx = 0 ; c.gridy = 2;
	c.gridwidth = 5 ; c.gridheight = 1 ;
	c.weightx = 1 ; c.weighty = 1 ;
	this.add(pan,c);

	}
	//Ce constructeur est fait pour reprendre une partie � partir d'un object de 
	// classe Partie
	public Fen2(Partie pp){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Toolkit tk = Toolkit.getDefaultToolkit() ;
		Dimension dimEcran = tk.getScreenSize() ;
		this.setBounds(0, 0,dimEcran.width, dimEcran.height);
		this.setResizable(false);
		this.getContentPane().setBackground(Color.white);
		GridBagLayout g = new GridBagLayout() ;
		this.setLayout(g);
		GridBagConstraints c = new GridBagConstraints() ;
		c.fill = GridBagConstraints.BOTH ;
		infoJeu= new infoJeu();
		infoJoueur= new infoJoueur();
		pan=new Plateau(1,(infoJeu)infoJeu,pp,(infoJoueur)infoJoueur,this);
		
		BarreAction= new BarreAction((Plateau)pan,this);
		c.gridx = 0 ; c.gridy = 0 ;
		c.gridwidth = 1 ; c.gridheight = 1 ;
		c.weightx = 1 ; c.weighty = 1 ;
		this.add(infoJeu,c);
		c.gridx = 2 ; c.gridy = 0 ;
		c.gridwidth = 1 ; c.gridheight = 1 ;
		c.weightx = 1 ; c.weighty = 1 ;
		this.add(infoJoueur,c);
		c.gridx = 1 ; c.gridy = 0 ;
		c.gridwidth = 1 ; c.gridheight = 1 ;
		c.weightx = 1 ; c.weighty = 1 ;
		this.add(Titre,c);
		c.gridx = 0 ; c.gridy = 30;
		c.gridwidth = 1 ; c.gridheight = 1 ;
		c.weightx = 1 ; c.weighty = 1 ;
		this.add(BarreAction,c);
		c.gridx = 0 ; c.gridy = 2;
		c.gridwidth = 5 ; c.gridheight = 1 ;
		c.weightx = 1 ; c.weighty = 1 ;
		this.add(pan,c);
	
		}
}



class BarreAction extends JPanel implements ActionListener
{

	private JButton sauver= new JButton("Sauver");
	private JButton quitter = new JButton("quitter");
	private JButton suspendre = new JButton("Suspendre");

	private Plateau fen;
	private ExitDialog exit;
	private Fen2 f;
	private JButton revenir=new JButton("Menu Principal");
	public BarreAction(Plateau fen,Fen2 f)
	{
		
		this.setBackground(Color.white);
		this.f=f;
		this.fen=fen;
		sauver.setCursor(new Cursor(12));
		quitter.setCursor(new Cursor(12));
		suspendre.setCursor(new Cursor(12));
		revenir.setCursor(new Cursor(12));
		
		quitter.setBackground(Color.ORANGE);
		sauver.setBackground(Color.ORANGE);
		suspendre.setBackground(Color.ORANGE);
		revenir.setBackground(Color.ORANGE);
		
		sauver.setIcon(new ImageIcon("save.png"));
		sauver.setPreferredSize(new Dimension(130,40));
		quitter.setIcon(new ImageIcon("quit.png"));
		quitter.setPreferredSize(new Dimension(130,40));
		suspendre.setIcon(new ImageIcon("pause.png"));
		revenir.setPreferredSize(new Dimension(180,40));
		revenir.setIcon(new ImageIcon("back.png"));

		this.setLayout(new FlowLayout());
		this.add(sauver);
		this.add(quitter);
		this.add(suspendre);
		this.add(revenir);	
		sauver.addActionListener(this);
		quitter.addActionListener(this);
		suspendre.addActionListener(this);
		revenir.addActionListener(this);

	}
	@Override
	public void actionPerformed(ActionEvent ev) {
		String Filename=new String("");
		ObjectOutputStream o;
		ObjectInputStream i;
if(ev.getSource()== sauver)
{
	Filename=exit.saveActions(false);
if(Filename!=""){
	try {
		o=new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File(Filename+".crq"))));
		o.writeObject(fen.getP());
		o.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}}
}
	if(ev.getSource()== quitter)
	{
		int retour=ExitDialog.exitActions();
		switch(retour)
		{
		case 0 :
			sauver.doClick();
			f.setVisible(false);
			break;
		case 4:
			break;
		case 1 :
			f.setVisible(false);
break;
		case 2 :
			break;
		}

	}
	if(ev.getSource()==suspendre)
	{
		Suspendre s=new Suspendre();
		s.setModal(true);
		s.setVisible(true);
	}
	if(ev.getSource()==revenir){
		Menu men=new Menu();
		int retour=ExitDialog.exitActions();
		switch(retour)
		{
		case 0 :
			sauver.doClick();
			f.setVisible(false);
			men.setVisible(true);
			break;
		case 4:
			break;
		case 1 :
			f.setVisible(false);
			men.setVisible(true);
break;
		case 2 :
			break;
		}
	}
	}

}
class infoJeu extends JPanel
{
	private JLabel Score = new JLabel("Score : ");
private JLabel Caseactu= new JLabel("Caseactu");

public void setCaseActu(int n)
{
	this.Caseactu.setText("   Case Actuelle : "+n);
}
public void setScore(int n)
{
	this.Score.setText("Score : "+n);
}
public infoJeu()
{
	
	Score.setForeground(Color.getHSBColor(57,80,120));
	Score.setFont(new Font("Hobo STD",4,28));
	Caseactu.setForeground(Color.BLACK);
	Caseactu.setFont(new Font("Hobo STD",4,28));
	//this.setBounds(0, 0, 200, 200);
	this.setLayout(new FlowLayout());
	Score.setIcon(new ImageIcon("player_idle.gif"));
	this.setLayout(new FlowLayout());
	this.add(Score);
	this.add(Caseactu);
	this.setBackground(Color.white);
	this.setPreferredSize(new Dimension(100,100));
	this.setMinimumSize(new Dimension(100,100));
	this.setMaximumSize(new Dimension(100,100));
	//this.setBorder(BorderFactory.createTitledBorder(""));

}
	}

class infoJoueur extends JPanel{
	private JLabel NomJoueur = new JLabel("Name : Elmsente7 li 7etem el3alem");
	private JLabel BestScore=new JLabel("Meilleur score : 0");
	private JLabel avatar= new JLabel(new ImageIcon("as.png"));

	public infoJoueur()
	{
		GridBagLayout g = new GridBagLayout() ;
		this.setLayout(g);
		GridBagConstraints c = new GridBagConstraints() ;
		c.fill = GridBagConstraints.BOTH ;
		

		c.gridx = 0 ; c.gridy = 0 ;
		c.gridwidth = 1 ; c.gridheight = 2 ;
		c.weightx = 1 ; c.weighty = 1 ;
		this.add(avatar,c);
		c.gridx = 1 ; c.gridy = 0 ;
		c.gridwidth = 1 ; c.gridheight = 1 ;
		c.weightx = 1 ; c.weighty = 1 ;
		this.add(NomJoueur,c);
		c.gridx = 1 ; c.gridy = 1 ;
		c.gridwidth = 1 ; c.gridheight = 1 ;
		c.weightx = 1 ; c.weighty = 1 ;
		this.add(BestScore,c);
		c.gridx = 0 ; c.gridy = 0 ;
		c.gridwidth = 100 ; c.gridheight = 200 ;
		c.weightx = 1 ; c.weighty = 1 ;
		this.setBackground(Color.white);
		//this.add(new BackgroundPanel(new ImageIcon("contour.png").getImage()),c);
		this.setPreferredSize(new Dimension(400,100));
		this.setMinimumSize(new Dimension(400,100));
		this.setMaximumSize(new Dimension(400,100));

	}
	
	void setBestScore(int n)
	{
		BestScore.setForeground(Color.getHSBColor(57,80,120));
		BestScore.setFont(new Font("Hobo STD",4,24));
		BestScore.setText("Meilleur Score : "+n);
	}
	void setNomJoueur(String name)
	{
		NomJoueur.setForeground(Color.black);
		NomJoueur.setFont(new Font("Hobo STD",4,24));
		NomJoueur.setText("Joueur : "+name);
	}
	
	void setAvatar(String path)
	{
		avatar.setIcon(new ImageIcon(path));
	}
}

class ErrorSquareException extends Exception
{
public void AfficherMessage()
{
	Thread music=new MusiqueFond("Sons/erreurPacman.wav",0);
	music.start();
	System.err.println(" Vous avez cliqu� sur la mauvaise case");
}
}

class Plateau extends JPanel implements  ActionListener
{ 
//try {
    //Thread.sleep(1000);
//} catch(InterruptedException ex) {
  //  Thread.currentThread().interrupt();
//}
	private GridBagConstraints c;
    private JButton De= new JButton("");
    private JButton arreter=new JButton("");
    private infoJeu Info;
    private infoJoueur infoj;
	private JButton Boutons[]= new JButton[150];
	private int dep=0;
	private int depo=0;
	private int tscore=0;
	private int act;
	private Fen2 ff;
	public static int x[] = new int[100];
	public static int y[] = new int[100];
	private EcouteBouton ecouts[]= new EcouteBouton[150];
	private Partie p;
	private int[] xdirection=new int[20];
	private int[] ydirection=new int[20];
	private JLabel infoDe1= new JLabel(new ImageIcon("1.png"));
	private JLabel infoDe3= new JLabel(new ImageIcon(""));
	private JLabel infoDe4= new JLabel(new ImageIcon(""));
	private static final int tailleImage = 64;
	private static final int tailleDefinition = 25;
	private static final int MaxDefinition = 100;
	private Timer timer;
	private int lll;
	static private String[] Images=new String[200];
	static private String[][] Definitions=new String[100][2];
	private JTextArea text=new JTextArea("");
	private int nbrLigne=0;
	private JLabel infoDe2= new JLabel(new ImageIcon("6.png"));
	private String Historic= new String(" Historique des actions \n");
	private JLabel obtenu=new JLabel("");
	private JLabel Dice=new JLabel(new ImageIcon("dee.gif"));
	
	private WinDefinition windef;
	private WinPicture winpic;
	private JLabel dice=new JLabel(new ImageIcon("dee.gif"));
	public Partie getP()
	{
		return p;
	
}

public void setP(Partie p)
{
	this.p=p;
}
public Plateau (int direction,infoJeu infoJeu,String name, infoJoueur infojj,String path, Fen2 fen2)
{ 
	Chargement();
	this.setBackground(Color.white);
	this.ff=fen2;
	this.infoj=infojj;
	int bestscore=Search(name);
	infoj.setBestScore(bestscore);
	infoj.setNomJoueur(name);
	infoj.setAvatar(path);
	p=new Partie(direction);
	p.setJoueur(new Joueur(name,bestscore));
	p.setAvatar(path);
	this.Info=infoJeu;
    De.setIcon(new ImageIcon("Dice.gif"));
    direction=p.getDirection();

    De.setPreferredSize(new Dimension(25,25));
	De.setMinimumSize(new Dimension(25,25));
	De.setMaximumSize(new Dimension(25,25));
	arreter.setPreferredSize(new Dimension(25,25));
	arreter.setMinimumSize(new Dimension(40,40));
	arreter.setMaximumSize(new Dimension(25,25));
	arreter.setIcon(new ImageIcon("stop.png"));
	De.setBackground(Color.orange);
	arreter.setBackground(Color.orange);
	De.setCursor(new Cursor(12));
	arreter.setCursor(new Cursor(12));
	De.setToolTipText("Cliquez ici pour lancer les d�s !");
	arreter.setToolTipText("Cliquez ici pour arr�ter les d�s");

arreter.setEnabled(false);
switch(direction){
case 1 :
	XGeneration(13,14,5,9,-1);
	YGeneration(12,13,3,15,1);
	break;
case 2:
	XGeneration(14,13,5,18,1);
	YGeneration(12,13,3,15,1);
	break;
case 3 :

XGeneration(13,14,5,9,-1);
	YGeneration(11,10,3,8,-1);
	break;
case 4 :
	XGeneration(14,13,5,18,1);
	YGeneration(11,10,3,8,-1);
	break;
}

GridBagLayout g = new GridBagLayout() ;
this.setLayout (g) ;
 c = new GridBagConstraints() ;

c.fill = GridBagConstraints.BOTH ;
c.gridx=0;c.gridy=0;
this.add(De,c);
for (int i = 0 ; i<=99 ; i++)
{ c.gridx = x[i] ; c.gridy = y[i] ;
c.gridwidth = 1 ; c.gridheight = 1 ;
c.weightx = 1 ; c.weighty = 1 ;
Boutons[i]=new JButton(new ImageIcon(typeCase(i)));
Boutons[i].setPreferredSize(new Dimension(40,25));
Boutons[i].setMinimumSize(new Dimension(40,25));
Boutons[i].setMaximumSize(new Dimension(40,25));
Boutons[i].addActionListener(this);
Boutons[i].setContentAreaFilled(false);
ecouts[i]= new EcouteBouton(i,this );
Boutons[i].addActionListener(ecouts[i]);
Boutons[i].setContentAreaFilled(false);
Boutons[i].setCursor(new Cursor(12));

this.add (Boutons[i], c) ;
}
ecouts[101]= new EcouteBouton(101,this );
De.addActionListener(ecouts[101]);
ecouts[102]= new EcouteBouton(102,this );
arreter.addActionListener(ecouts[102]);
c.gridx=27;c.gridy=0;
c.gridwidth=1;c.gridheight=10;

text.setEditable(false);
text.setLineWrap(true);
text.setFont(new Font("Times New Roman",1,14));
text.setForeground(Color.blue);
text.setWrapStyleWord(true);
text.setOpaque(false);
text.setText("Historique des actions");
JScrollPane historique=new JScrollPane(text);
historique.setPreferredSize(new Dimension(150,50));
historique.setMaximumSize(new Dimension(100,50));
historique.setMinimumSize(new Dimension(100,50));
historique.setOpaque(false);
text.setToolTipText("Suivez l'encha�nement de vos actions sur ce pav�");

this.add(historique,c);
Boutons[99-p.getCaseActu()].setIcon(new ImageIcon(Cursor(99-p.getCaseActu())));
Info.setScore(p.getScoreEnCours());
Info.setCaseActu((p.getCaseActu()+1));
c.gridx=0;c.gridy=1;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(infoDe3,c);
c.gridx=0;c.gridy=3;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(infoDe4,c);
c.gridx=0;c.gridy=1;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(infoDe1,c);
c.gridx=0;c.gridy=3;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(infoDe2,c);

c.gridx=0;c.gridy=6;
c.gridwidth = 1 ; c.gridheight = 1 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(arreter,c);
c.gridx=0;c.gridy=7;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(obtenu,c);
//c.gridx=3;c.gridy=0;
//c.gridwidth = 1 ; c.gridheight = 2 ;
//c.weightx = 1 ; c.weighty = 1 ;
//this.add(Dice,c);
c.gridx=0;c.gridy=0;
c.gridwidth = 300 ; c.gridheight = 400 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(new ImagePanel(new ImageIcon("dir"+direction+".png").getImage()),c);
this.add(new ImagePanel(new ImageIcon("fondd"+direction+".png").getImage()),c);
//this.add(new BackgroundPanel(new ImageIcon("contour.png").getImage()),c);
}
public Plateau(int direction, infoJeu infoJeu, Partie pp,infoJoueur infojj, Fen2 fen2) {
	
    De.setIcon(new ImageIcon("Dice.gif"));
    this.setBackground(Color.white);
	arreter.setBackground(Color.orange);
	De.setCursor(new Cursor(12));
	arreter.setCursor(new Cursor(12));
	setP(pp);
	this.ff=fen2;
	Chargement();
	this.infoj=infojj;
	infoj.setBestScore(pp.getJoueur().getBestScore());
	infoj.setNomJoueur(pp.getJoueur().toString());
	infoj.setAvatar(pp.getAvatar());
	direction=pp.getDirection();
	this.Info=infoJeu;
	this.setBounds(0, 0, 1366, 768);
	De.setPreferredSize(new Dimension(25,25));
	De.setMinimumSize(new Dimension(25,25));
	De.setMaximumSize(new Dimension(25,25));
	arreter.setPreferredSize(new Dimension(25,25));
	arreter.setMinimumSize(new Dimension(40,40));
	arreter.setMaximumSize(new Dimension(25,25));
	arreter.setIcon(new ImageIcon("stop.png"));
	De.setBackground(Color.orange);
	De.setToolTipText("Cliquez ici pour lancer les d�s !");
	arreter.setToolTipText("Cliquez ici pour arr�ter les d�s");
	arreter.setBackground(Color.orange);
	arreter.setEnabled(false);
	switch(direction){
	case 1 :
		XGeneration(13,14,5,9,-1);
		YGeneration(12,13,3,15,1);
		break;
	case 2:
		XGeneration(14,13,5,18,1);
		YGeneration(12,13,3,15,1);
		break;
	case 3 :

	XGeneration(13,14,5,9,-1);
		YGeneration(11,10,3,8,-1);
		break;
	case 4 :
		XGeneration(14,13,5,18,1);
		YGeneration(11,10,3,8,-1);
		break;
	}
	
//setSize (640, 480) ;
GridBagLayout g = new GridBagLayout() ;
this.setLayout (g) ;
 c = new GridBagConstraints() ;

c.fill = GridBagConstraints.BOTH ;
c.gridx=0;c.gridy=7;
c.gridwidth = 1 ; c.gridheight = 1 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(obtenu,c);
c.gridx=0;c.gridy=0;
this.add(De,c);
for (int i = 0 ; i<=99 ; i++)
{ c.gridx = x[i] ; c.gridy = y[i] ;
c.gridwidth = 1 ; c.gridheight = 1 ;
c.weightx = 1 ; c.weighty = 1 ;
Boutons[i]=new JButton(new ImageIcon(typeCase(i)));
Boutons[i].setPreferredSize(new Dimension(25,25));
Boutons[i].setMinimumSize(new Dimension(25,25));
Boutons[i].setMaximumSize(new Dimension(25,25));
Boutons[i].addActionListener(this);
ecouts[i]= new EcouteBouton(i,this );
Boutons[i].addActionListener(ecouts[i]);
Boutons[i].setCursor(new Cursor(12));
this.add (Boutons[i], c) ;
}
ecouts[101]= new EcouteBouton(101,this );
De.addActionListener(ecouts[101]);
ecouts[102]= new EcouteBouton(102,this );
arreter.addActionListener(ecouts[102]);
c.gridx=27;c.gridy=0;
c.gridwidth=1;c.gridheight=10;


text.setEditable(false);
text.setLineWrap(true);
text.setFont(new Font("Times New Roman",1,14));
text.setForeground(Color.blue);
text.setWrapStyleWord(true);
text.setOpaque(false);
text.setText("Historique des actions");
JScrollPane historique=new JScrollPane(text);
historique.setPreferredSize(new Dimension(150,50));
historique.setMaximumSize(new Dimension(100,50));
historique.setMinimumSize(new Dimension(100,50));
historique.setOpaque(false);
text.setToolTipText("Suivez l'encha�nement de vos actions sur ce pav�");

this.add(historique,c);

Boutons[99].setIcon(new ImageIcon("Depart.png"));
Boutons[0].setIcon(new ImageIcon("Fin.png"));
Boutons[99-p.getCaseActu()].setIcon(new ImageIcon(Cursor(99-p.getCaseActu())));
Info.setScore(p.getScoreEnCours());
Info.setCaseActu((p.getCaseActu()+1));
c.gridx=0;c.gridy=1;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(infoDe3,c);

c.gridx=0;c.gridy=3;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(infoDe4,c);
c.gridx=0;c.gridy=1;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(infoDe1,c);
c.gridx=0;c.gridy=3;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(infoDe2,c);

c.gridx=0;c.gridy=6;
c.gridwidth = 1 ; c.gridheight = 1 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(arreter,c);
c.gridx=0;c.gridy=7;
c.gridwidth = 1 ; c.gridheight = 2 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(obtenu,c);
c.gridx=0;c.gridy=0;
c.gridwidth = 300 ; c.gridheight = 400 ;
c.weightx = 1 ; c.weighty = 1 ;
this.add(new ImagePanel(new ImageIcon("dir"+direction+".png").getImage()),c);
this.add(new ImagePanel(new ImageIcon("fondd"+direction+".png").getImage()),c);
}
public void Chargement(){

int i=0,j=0;
//D:\\exo1\\
File f=new File("Images");
String Filename=new String("");
BufferedInputStream in;
String word=new String("");
byte[] buf= new byte[255];
for(File file : f.listFiles())
{
	Filename=file.getName();
	if (Filename.indexOf("gif")!= -1){
	Images[i]=Filename.substring(0, Filename.indexOf(".gif"));}
	else{Images[i]=Filename.substring(0, Filename.indexOf(".jpg"));}
	i++;
}
i=0;
f=new File("Definitions");
for(File file : f.listFiles())
{
	Filename=file.getName();
	Definitions[i][0]=Filename.substring(0, Filename.indexOf(".txt"));
	try {
		in=new BufferedInputStream(new FileInputStream(new File("Definitions\\"+Filename)));
		j=0;
		try {
			in.read(buf);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		word="";
		while(j<=buf.length-1 && buf[j] != 0)
		{
        	word+= (char)buf[j];
        	buf[j]=0;
        	j++;
        }
		buf= new byte[255];
		Definitions[i][1]=word;
        }
	 catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	i++;
}
}

public String ImageDe(int i)
{
	return i+".png";
}
//retourne l'image d'une case vide
 public String typeCase(int i)
 {
	 Case cas=p.getCase(i);
	 if (cas instanceof Bonus)
	 {
		 return ("Bonus.png");
	 }
	 if (cas instanceof Malus)
	 {
		 return ("Malus.png");
	 }
	 if (cas instanceof Definition)
	 {
		 return ("Definition.png");
	 }
	 if(cas instanceof Picture)
	 {
		 return("Image.png");
	 }
	 if (cas instanceof Depart)
	 {
		 return ("Depart.png");
	 }
	 if (cas instanceof Saut)
	 {
		 return ("Saut.png");
	 }
	 if (cas instanceof Fin)
	 {
		 return ("Fin.png");
	 }
	 return "Parcours.png";
 }
 //Chercher un joueur par son nom et retourner son bestScore
 public int Search(String nom)
 {
	 String t = "";
	 boolean eof=false;
	 ObjectInputStream kl;
	 Joueur j=new Joueur();
	 try {
	 kl=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("BestScores.txt"))));
	 while(!eof && (t.equalsIgnoreCase(nom))==false)
	 {
	 try {
	 j=(Joueur)kl.readObject();
	 t=j.toString();
	 } catch (EOFException e)
	 { eof = true ; // il passera a true lors d?une rencontre de fin de fichier
	 }
	 catch (ClassNotFoundException e) {
	 // TODO Auto-generated catch block
	 e.printStackTrace();
	 }
	 }
	 } catch (FileNotFoundException e) {
	 // TODO Auto-generated catch block
	 e.printStackTrace();
	 } catch (IOException e) {
	 // TODO Auto-generated catch block
	 e.printStackTrace();
	 }
	 if ((t.equalsIgnoreCase(nom))==false){
	 j=new Joueur();
	 }
	 return j.getBestScore();

 }
 
class EcouteBouton implements ActionListener
{

	int n;
	int i;
	Container contenu;
	//Fonction qui v�rifie si on a cliqu� la bonne case
	public void Valid(int n)throws ErrorSquareException
	{
		if (n!= (99-p.getCaseActu()))throw new  ErrorSquareException();
	}
	EcouteBouton(int n,Container contenu)
	{
		this.n=n;
		this.contenu=contenu;
	}
	@Override
	public void actionPerformed(ActionEvent ev)	
	{
		int l=0;
		ImagePanel kk;
		int k=0;
		int k1=0,k2 = 0,k3=0,k4=0;
		 int actu=(int)(Math.random()*(3-1))+1;
		 int actu2=(int)(Math.random()*(3-1))+1;
int actual=p.getCaseActu();
		if (ev.getSource()!=De && ev.getSource() != arreter){
		Case cas=p.getCase(n);
		
		
		int i;
		if(n<=100){
			
			try{
				Valid(n);
				actual=p.getCaseActu();
				Boutons[99-p.getCaseActu()].setIcon(new ImageIcon(typeCase(99-p.getCaseActu())));
				tscore=p.getScoreEnCours();
				if (cas != null){cas.traitement();p.setClicked(true);}			
		if(cas instanceof Definition)
		{
			k=(int)(Math.random()*(tailleDefinition));
			windef=new WinDefinition(Definitions[k][1],Definitions[k][0],p);
			windef.setModal(true);
			windef.setVisible(true);
			p.setClicked(true);
		}
		if(cas instanceof Picture)
		{
			p.setClicked(true);
			k1=(int)(Math.random()*(tailleImage-1));
			while(k2==k1){
			k2=(int)(Math.random()*(tailleImage-1));}
			while(k3==k1 || k3==k2){
			k3=(int)(Math.random()*(tailleImage-1));}
			while(k4==k1 || k4==k2||k4==k3){
			k4=(int)(Math.random()*(tailleImage-1));}
k=(int)(Math.random()*(4-1))+1;
switch(k){
case 1:
winpic=new WinPicture(Images[k1],new ImageIcon("Images\\"+Images[k1]+".gif"),new ImageIcon("Images\\"+Images[k2]+".gif"),new ImageIcon("Images\\"+Images[k3]+".gif"),new ImageIcon("Images\\"+Images[k4]+".gif"),1,p);
break;
case 2:
	winpic=new WinPicture(Images[k2],new ImageIcon("Images\\"+Images[k1]+".gif"),new ImageIcon("Images\\"+Images[k2]+".gif"),new ImageIcon("Images\\"+Images[k3]+".gif"),new ImageIcon("Images\\"+Images[k4]+".gif"),2,p);
break;
case 3:
	winpic=new WinPicture(Images[k3],new ImageIcon("Images\\"+Images[k1]+".gif"),new ImageIcon("Images\\"+Images[k2]+".gif"),new ImageIcon("Images\\"+Images[k3]+".gif"),new ImageIcon("Images\\"+Images[k4]+".gif"),3,p);
break;
case 4 :
	winpic=new WinPicture(Images[k4],new ImageIcon("Images\\"+Images[k1]+".gif"),new ImageIcon("Images\\"+Images[k2]+".gif"),new ImageIcon("Images\\"+Images[k3]+".gif"),new ImageIcon("Images\\"+Images[k4]+".gif"),4,p);
	break;
}
			winpic.setModal(true);			
			winpic.setVisible(true);
		}
		if (p.getCaseActu()>99)
		{
			
			p.setCaseActu(99-(p.getCaseActu()-99));
			Thread music=new MusiqueFond("Sons/Finkiw.wav",0);
			music.start();
		}
		if(p.getCaseActu()<0)
		{
			p.setCaseActu(Math.abs(p.getCaseActu()));
			Info.setCaseActu((p.getCaseActu()+1));

		}
		if(p.getCase(99-p.getCaseActu())!= null || p.getCaseActu()==0 || p.getCaseActu()==99){p.setClicked(false);}
		Boutons[99-p.getCaseActu()].setIcon(new ImageIcon(Cursor(99-p.getCaseActu())));
		Info.setCaseActu((p.getCaseActu()+1));
		if (tscore<p.getScoreEnCours()){
		timer = new Timer(50,new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
            	
		if(tscore<=p.getScoreEnCours()) {
		Info.setScore(tscore);
		tscore++;
		Thread music=new MusiqueFond("Sons/ScoreAugmente.wav",0);
		music.start();

                } else {
                    timer.stop();
            		Info.setScore(p.getScoreEnCours());
                }                
                repaint();
                revalidate();
            }
        });}
		else{		timer = new Timer(50,new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
            	
if(tscore>=p.getScoreEnCours()) {
Info.setScore(tscore);
tscore--;

                } else {
                    timer.stop();
            		Info.setScore(p.getScoreEnCours());
                }                
                repaint();
                revalidate();
            }
        });
			
		}
		timer.start();

		//Info.setScore(p.getScoreEnCours());
		if (nbrLigne>13){Historic="";nbrLigne=0;}
		if(p.getCaseActu()-actual >0){Historic+="Tu as avanac� de "+(p.getCaseActu()-actual)+" cases\n";}
		else{Historic+="Tu as recul� de "+(Math.abs(p.getCaseActu()-actual))+" cases\n";}
		text.setText(Historic);
		nbrLigne++;
		
		if(n==0){
			
			JOptionPane.showMessageDialog(null, "Bravo ! Vous avez fini la partie !");
			//fanfare
			Thread music=new MusiqueFond("Sons/Finkiw.wav",0);
			music.start();
			if(p.getScoreEnCours()>p.getJoueur().getBestScore())
			{
				p.getJoueur().setBestScore(p.getScoreEnCours());
			}
			GameOver g=new GameOver(p.getJoueur(),p.getScoreEnCours(),ff);
		
		}
}
		
	
		catch(ErrorSquareException e)
		{
			System.out.print("ErrorSquareException:");
			e.AfficherMessage();
			JOptionPane.showMessageDialog(null,"Vous avez cliqu� sur la mauvaise case\nVous devez cliquer sur la case "+(p.getCaseActu()+1), "Exception !",JOptionPane.ERROR_MESSAGE);

		}
		}
		}
	else //si on clique sur le d�
	{
		if(ev.getSource()==arreter){
			
//			for(i=0;i<=10;i++)
//			{
////				 timer = new Timer(1000,this);
////			        timer.start();               
//				
//				
//				contenu.revalidate();
//				removeAll();
//				contenu.repaint();
//			}
if(p.isClicked2()==false){JOptionPane.showMessageDialog(null,"Vous devez relancer les d�s");}
else{
		if((p.isClicked())!=true){JOptionPane.showMessageDialog(null,"Vous devez cliquer sur la case actuelle pour continuer","Erreur",JOptionPane.ERROR_MESSAGE);}
		else{
			De.setEnabled(false);
			infoDe3.setIcon(null);
			infoDe4.setIcon(null);
			actual=p.getCaseActu();

//		Boutons[99-p.getCaseActu()].setIcon(new ImageIcon(typeCase(99-p.getCaseActu())));
		actu=(int)(Math.random()*(6))+1;
		infoDe1.setIcon(new ImageIcon(actu+".png"));
		actu2=(int)(Math.random()*(6))+1;
		infoDe2.setIcon(new ImageIcon(actu2+".png"));
		actu2+=actu;
		dep=actu2;
		obtenu.setIcon(new ImageIcon("a"+actu2+".png"));
		depo=dep;
		act=p.getCaseActu();
		  timer = new Timer(500,new ActionListener() {

	            @Override
	            public void actionPerformed(ActionEvent arg0) {
	            	
if(dep>0) {
	Boutons[Math.abs(98-act-(depo-dep)+1)].setIcon(new ImageIcon(typeCase(Math.abs(98-act-(depo-dep)+1))));
	Boutons[Math.abs(98-act-(depo-dep))].setIcon(new ImageIcon(Cursor(Math.abs(98-act-(depo-dep)))));
	Info.setCaseActu(100-Math.abs(98-act-(depo-dep)));
dep--;

	                } else {
	                    timer.stop();
	            		Info.setCaseActu((p.getCaseActu()+1));
	            		De.setEnabled(true);
	                }                
	                repaint();
	                validate();
	            }
	        });
	        timer.start();
            p.setCaseActu(p.getCaseActu()+actu2);
		if (p.getCaseActu()>99)
		{
			Thread music=new MusiqueFond("Sons/Finkiw.wav",0);
			music.start();
			p.setCaseActu(99-(p.getCaseActu()-99));
		}
		if(p.getCaseActu()<0)
		{
			p.setCaseActu(Math.abs(p.getCaseActu()));
			Info.setCaseActu((p.getCaseActu()+1));

		}
		//Boutons[99-p.getCaseActu()].setIcon(new ImageIcon(Cursor(99-p.getCaseActu())));
		}
		if(p.getCase(99-p.getCaseActu())!= null || p.getCaseActu()==0 || p.getCaseActu()==99){p.setClicked(false);}
		if (nbrLigne>13){Historic="";nbrLigne=0;}

		if(p.getCaseActu()-actual >0){Historic+="Tu as avanc� de "+(p.getCaseActu()-actual)+" cases\n";}
		else{Historic+="Tu as recul� de "+(Math.abs(p.getCaseActu()-actual))+" cases\n";}
		nbrLigne++;
		text.setText(Historic);
		p.setClicked2(false);
		arreter.setEnabled(false);

	}}
		if(ev.getSource()== De)
		{
			lll=99;
			

			if((p.isClicked())!=true){JOptionPane.showMessageDialog(null,"Vous devez cliquer sur la case actuelle pour continuer","Erreur",JOptionPane.ERROR_MESSAGE);}
			else{
			p.setClicked2(true);
			infoDe3.setIcon(new ImageIcon("2.gif"));
			infoDe4.setIcon(new ImageIcon("3.gif"));
			infoDe1.setIcon(new ImageIcon("az.png"));
			infoDe2.setIcon(new ImageIcon("az.png"));}
arreter.setEnabled(true);

		}
}
		
	}
	}


//begin: l'abcisse de l'origine,next : l'abcisse de la case apr�s, et p est 
//l'orientation, p=1 si au sens oppos� de l'horloge, sinon p=-1 si au sens de 
//l'horloge
public void XGeneration(int begin,int next,int step,int limit2,int p)
{
	xdirection[0]=1;
	int limit1,val,i,cpt;
	cpt=1;
	limit1=next;
	val=next;
	i=2;
	x[0]=begin;
	x[1]=next;
	while(i<100)
	{
		if (limit1 > limit2)
		{val--;
		x[i]=val;
		}
		else
		{val++;
		x[i]=val;
		}
		i++;
		if ((val==limit1) || (val==limit2))
		{if(cpt<=16){xdirection[cpt]=i-1;}
		cpt++;
			p=p*(-1);
		step+=4;
		limit1=limit2;
		limit2=val+(step*p);
		}
	}

}

//Pour savoir quelle direction doit voir le personnage et placer le curseur 
//selon le type de case
public String Cursor(int i)
{
	 String Chemin=new String("Cursor");
	 int xcpt=0,ycpt=0;
	 xcpt=0;
	 while (ydirection[ycpt]< i && ycpt != 7)
	 {
		 ycpt++;
	 }
	 while((xdirection[xcpt])< i && xcpt !=7)
	 {
		 xcpt++;
	 }
	 
Case cas=p.getCase(i);
if (cas instanceof Bonus)
	 {
		 Chemin+="Bonus";
	 }
	 if (cas instanceof Malus)
	 {
		 Chemin+="Malus";
	 }
	 if (cas instanceof Definition)
	 {
		 Chemin+="Definition";
	 }
	 if(cas instanceof Picture)
	 {
		 Chemin+="Image";
	 }
	 if (cas instanceof Depart)
	 {
		 Chemin+="Depart";
	 }
	 if (cas instanceof Fin)
	 {
		 Chemin+="Fin";
	 }
	 if (cas instanceof Saut)
	 {
		 Chemin+="Saut";
	 }
if (cas == null){Chemin+="Parcours"	;} 
int xx=1,yy=1;
switch(p.getDirection())
{
case 1 :
	xx=0;yy=0;
	break;
case 2 :
	xx=1;yy=0;
	break;
case 3 :
	xx=0;yy=1;
	break;
case 4 :
	xx=1;yy=1;
	break;
}
if ((xcpt%2)==xx)
{
	Chemin+="Gauche";
	
}
else
{
	Chemin+="Droite";
}
if ((ycpt%2)==yy)
{
	Chemin+="Bas.gif";
	
}
else
{
	Chemin+="Haut.gif";
}
	 return Chemin;
}
public void YGeneration(int begin,int next,int step,int limit2,int p)
{
	ydirection[0]=0;

	int limit1,val,i,cpt;
	cpt=1;
	limit1=next;
	val=next;

	i=2;
	y[0]=begin;
	y[1]=next;
	while(i<100)
	{
		if (limit1 > limit2)
		{val--;
		y[i]=val;
		}
		else
		{val++;
		y[i]=val;
		}
		i++;
		if ((val==limit1) || (val==limit2))
		{ydirection[cpt]=i-1;
		
		cpt++;
			p=p*(-1);
		step+=4;
		limit1=limit2;
		limit2=val+(step*p);
		}
	}
}


public void actionPerformed(ActionEvent arg0) {
	// TODO Auto-generated method stub
	
}

public String getImages(int i) {
	return Images[i];
}

public void setImages(String images,int i) {
	Images[i] = images;
}
}
public class TP2
{ public static void main (String args[])
{
	try {
	     UIManager.setLookAndFeel( "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
	}
	catch(Exception e){
	     System.out.println("Erreur de chargement de Nimbus !");
	}
	Menu men= new Menu();
	men.setVisible(true);
	
	/**
	Thread music=new MusiqueFond("Sons/Applaude.wav",0);
	music.start();  
	**/
	
}
}