

import java.io.File;

public class FiltreFichiers extends javax.swing.filechooser.FileFilter
{
	// M�thode abstraite h�rit�e "accept"
	
	public boolean accept(File f) {
		return f.getName().toLowerCase().endsWith(".crq")|| f.isDirectory();	
	}
	
    public String getDescription() {
        return "Fichier CROAQ";
      }
}