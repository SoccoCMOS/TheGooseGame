

public interface Deplacement {
	public void deplacer(int d);
}
