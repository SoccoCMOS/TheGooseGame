
public class Case {
	protected Partie P;
private int num;

public void setP(Partie p)
{
	this.P=p;
}
public void traitement()
{
}

public Case(){
	
}


public int getNum() {
	return num;
}


public void setNum(int num) {
	this.num = num;
}

public Case(Partie p)
{
	this.P=p;
}
}
