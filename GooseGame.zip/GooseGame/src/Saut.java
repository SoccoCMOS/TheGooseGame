import java.io.Serializable;


public class Saut extends Case implements Serializable{
	public Saut(Partie p) {
		super(p);
		// TODO Auto-generated constructor stub
	}

	public void traitement()
	{
		 int actu=(int)(Math.random()*(99+99))-99;
		 P.setCaseActu(P.getCaseActu()+actu);
		 Thread music=new MusiqueFond("Sons/Saut.wav",0);
		 music.start();

	}
	public String toString()
	{
		return "Saut";
	}
}
