import javax.swing.* ;
//
import java.util.Timer;
import java.util.TimerTask;
import java.applet.AudioClip;
import java.awt.* ;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
//
import javax.swing.JOptionPane;

import Windows.JCoolButton;

import javax.swing.*;


public class Suspendre extends JDialog implements ActionListener{

	private JLabel sus=new JLabel(new ImageIcon("pause.gif"));
	private JButton fermer=new JButton("fermer");
	public Suspendre()
	{
		this.setBounds(300, 50, 401, 449);
this.setLayout(new FlowLayout());
this.setResizable(false);
this.getContentPane().setBackground(Color.white);

		this.add(sus);
		this.add(fermer);

		fermer.addActionListener(this);
		fermer.setBackground(Color.orange);
		fermer.setCursor(new Cursor(12));
		
	}
	public static void main(String[] args) {
Suspendre s=new Suspendre();
s.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
this.setVisible(false);
		
	}

}
