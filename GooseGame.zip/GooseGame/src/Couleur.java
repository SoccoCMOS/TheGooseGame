

public enum Couleur {
	Jaune, Verte, Rouge, Orange, Bleue, Rose, Noire;

}
