

import javax.swing.*;
import javax.swing.JFileChooser;


public class ExitDialog {
	
	// Attributes
	
	// Methods
	
	public static int exitActions()
	{
		int rep=JOptionPane.showConfirmDialog(null,"Voulez-vous quitter le jeu ?","Quitter CROAQ-Croaq",2,0,new ImageIcon("exit.png"));
		int rep2=4;
		if (rep==0)  // Clic sur OK
		{
			// Affichage d'une bo�te de dialogue de sauvegarde
			rep2=JOptionPane.showConfirmDialog(null,"Voulez-vous sauvegarder votre partie ?","Sauvegarder la partie",1,0,new ImageIcon("saveAs.png"));
			
		}
		return rep2;
	}
	
	public static String saveActions(boolean open)   // Retourne le chemin absolu du fichier o� sauvegarder la partie
	{
		String chemin=null;
		JFileChooser exp=new JFileChooser();
		
		exp.setFileFilter(new FiltreFichiers());
if (open){
		if (exp.showOpenDialog(null)==JFileChooser.APPROVE_OPTION)
		{
		chemin=exp.getSelectedFile().getAbsolutePath();
		}}
else{if (exp.showSaveDialog(null)==JFileChooser.APPROVE_OPTION)
{
chemin=exp.getSelectedFile().getAbsolutePath();
}}
		
		return chemin;
	}


}
