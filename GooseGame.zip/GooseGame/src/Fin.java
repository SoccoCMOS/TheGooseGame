import java.io.Serializable;


public class Fin extends Case implements Serializable{

	public Fin(Partie p) {
		super(p);
		// TODO Auto-generated constructor stub
	}
	public Fin()
	{
	super();	
	}
	public void traitement()
	{
	
	}
	public String toString()
	{
		return "Fin";
	}

}
