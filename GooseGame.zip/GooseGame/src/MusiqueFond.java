
public class MusiqueFond extends Thread {
	
	private Audio son;
	private int style;
	private boolean alive=false;
	
	
	
	public boolean getAlive() {
		return alive;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
	}

	public MusiqueFond(String fichierSon,int style)
	{
		son = new Audio(fichierSon);
		this.style=style;
	}
	
	public void run()
	{
		switch(style)
		{
		case 0 :  // Lire une seule fois
		{
			son.start();
			break;
		}
		case 1 :  // Lire en boucle
		{
			while (this.alive)
			{
				son.run();
			}
			break;
		}
		default :  // Lire une seule fois est la valeur par d�faut
		{
			son.start();
			break;
		}
		}
	}
	
	public void killThread()
	{
		this.interrupt();
	}

}
