
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Menu extends JFrame implements ActionListener{

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private BackgroundArea fondDecran;
private JLabel nomJeu;
private JButton newGame, loadGame, exit, howToPlay, bestScores,about;
private JPanel menu;
private Fen2 fen;
private Inscription inscription;

	public  Menu()
	{
		super(); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Menu du jeu");
		this.setSize(400,500);
		this.setResizable(false);
		this.setLocation(400, 150);
		//fondDecran= new BackgroundArea("fond.jpg");
		fondDecran= new BackgroundArea("fond.jpg");
		fondDecran.setLayout(new BorderLayout());
		
		this.setIconImage(new ImageIcon("icone.png").getImage());
		
		// Ajout nom du jeu
		nomJeu=new JLabel(new ImageIcon("petitLogo.png"));
		nomJeu.setPreferredSize(new Dimension(100,110));
		this.fondDecran.add(nomJeu,BorderLayout.NORTH);
		 
		/// Panel des boutons
		
		menu=new JPanel();
		menu.setOpaque(false);
		menu.setPreferredSize(new Dimension(100,100));
		menu.setMinimumSize(new Dimension(100,100));
		menu.setMaximumSize(new Dimension(100,100));
		menu.setBounds(200,200,10,10);
				
		// Ajout des boutons du menu
		
		newGame=new JButton("Nouvelle partie");
		newGame.setPreferredSize(new Dimension(200,50));
		newGame.setBackground(Color.blue);
		//newGame.setIcon(new ImageIcon("newGame.png"));
		newGame.setBorderPainted(false);
		newGame.setIconTextGap(10);
		newGame.setForeground(Color.white);
		newGame.setFont(new Font("Hobo Std",0,20));
		newGame.setBorder(BorderFactory.createTitledBorder(""));
		newGame.addActionListener(this);
		newGame.setCursor(new Cursor(12));
		
		loadGame=new JButton("Charger partie");
		loadGame.setPreferredSize(new Dimension(200,50));
		loadGame.setBackground(Color.gray);
		loadGame.setForeground(Color.white);
		loadGame.setFont(new Font("Hobo Std",0,20));
		loadGame.setBorder(BorderFactory.createTitledBorder(""));
		loadGame.addActionListener(this);
		loadGame.setCursor(new Cursor(12));
		
		howToPlay=new JButton("R�gles du jeu");
		howToPlay.setPreferredSize(new Dimension(200,50));
		howToPlay.setBackground(Color.pink);
		howToPlay.setForeground(Color.white);
		howToPlay.setFont(new Font("Hobo Std",0,20));
		howToPlay.setBorder(BorderFactory.createTitledBorder(""));
		howToPlay.addActionListener(this);
		howToPlay.setCursor(new Cursor(12));
		
		bestScores=new JButton("Meilleurs scores");
		bestScores.setPreferredSize(new Dimension(200,50));
		bestScores.setBackground(Color.green);
		bestScores.setForeground(Color.white);
		bestScores.setFont(new Font("Hobo Std",0,20));
		bestScores.setBorder(BorderFactory.createTitledBorder(""));
		bestScores.addActionListener(this);
		bestScores.setCursor(new Cursor(12));
		
		about=new JButton("A Propos");
		about.setPreferredSize(new Dimension(200,50));
		about.setBackground(Color.orange);
		about.setForeground(Color.white);
		about.setFont(new Font("Hobo Std",0,20));
		about.setBorder(BorderFactory.createTitledBorder(""));
		about.addActionListener(this);
		about.setCursor(new Cursor(12));
		
		exit=new JButton("Quitter");
		exit.setPreferredSize(new Dimension(200,50));
		exit.setBackground(Color.red);
		exit.setForeground(Color.white);
		exit.setFont(new Font("Hobo Std",0,20));
		exit.setBorder(BorderFactory.createTitledBorder(""));
		exit.addActionListener(this);
		exit.setCursor(new Cursor(12));
		exit.setBorder(null);
		
		
		menu.add(newGame);
		menu.add(loadGame);
		menu.add(howToPlay);
		menu.add(bestScores);
		menu.add(about);
		menu.add(exit);
		this.fondDecran.add(menu,BorderLayout.CENTER);
		this.getContentPane().add(fondDecran);
	}
	
	
	@SuppressWarnings("serial")
	class BackgroundArea extends JPanel
	{
	String chemin="";
	public BackgroundArea()
	{
		
	}
	public BackgroundArea(String s)
	{
		chemin=s;
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage(new ImageIcon(chemin).getImage(),0,0,500,500,null);
	}
	}

	public void actionPerformed(ActionEvent ev) {
		String Filename;
		ObjectInputStream i;
		// TODO Auto-generated method stub
		if (ev.getSource()==newGame)
		{
			inscription=new Inscription();
			inscription.setVisible(true);
			ThreadSaisie  t=new ThreadSaisie(inscription);
			if (inscription!=null) 
			{
				t.start();
			}
			
			if (t.isInterrupted())
			{
				System.out.println("Thread interrompu !");
			}
			
			this.setVisible(false);

		}
		else if (ev.getSource()==loadGame)
		{
			Filename=ExitDialog.saveActions(true);
			
		if(Filename!=null){
			try {
				i=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File(Filename))));
				Partie pp;
				pp=(Partie)i.readObject();
				for (int j=0;j<=99;j++)
				{
					if(pp.getCase(j)!=null){
						pp.setCasep(pp,j);
						
					}
				}
				fen=new Fen2(pp);
				fen.setVisible(true);
				

			} catch ( IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}this.setVisible(false);}
			
		} else if (ev.getSource()==howToPlay)
		{
			ReglesDuJeu j=new ReglesDuJeu();
			j.setVisible(true);
		} else if (ev.getSource()==bestScores)
		{
			MeilleurScore b=new MeilleurScore();
			b.setModal(true);
			b.setVisible(true);
		} else if (ev.getSource()==about)
		{	
			String s="<HTML> Ce TP est r�alis� par : <br/>  <br/> <b>** BELAHDJI Mohammed Walid** </b><br/> <b>** SI-MOUSSI Sara **</b> <br/><b>   ** Groupe 3 **</b> </HTML" ;
			JOptionPane.showMessageDialog(null,s,"ABOUT",0,new ImageIcon("binome.png"));
		} else 
		{
			this.setVisible(false);
		}
	}
}
