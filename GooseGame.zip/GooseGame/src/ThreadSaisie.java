

public class ThreadSaisie extends Thread
{
	Inscription fen;
	public ThreadSaisie(Inscription fen)
	{
		this.fen=fen;
	}
	
	public void majBouton(Inscription fen)
	{
	   while(fen.isVisible())
		{
			if ((fen.getSaisiePseudo()!=null)&&(fen.getValider()!=null)&& fen!=null && fen.getSaisiePseudo().getText()!= null)
			{
				if (fen.getSaisiePseudo().getText().isEmpty() )
				{
					fen.getValider().setEnabled(false);
				}
				else
				{
					fen.getValider().setEnabled(true);
				}
			}
		} 

	}
	
	public void run()
	{

		majBouton(fen);
	
	}


}