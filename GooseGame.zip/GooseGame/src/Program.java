

import javax.swing.ImageIcon;
import javax.swing.UIManager;




@SuppressWarnings("unused")
public class Program {
	
	public static void main(String args[])
	{
		try {
		     UIManager.setLookAndFeel( "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		}
		catch(Exception e){
		     System.out.println("Erreur de chargement de Nimbus !");
		}
		


		//ReglesDuJeu R=new ReglesDuJeu();
		//R.setVisible(true);
	}

}


///// TEST QUITTER/SAUVEGARDE

/**
String chemin=null;	
int rep=ExitDialog.exitActions();

switch (rep)
{
case 0 : // Ouverture de l'explorateur
{
	chemin=ExitDialog.saveActions();
	System.out.println(chemin);
}
case 1 : // Quitter sans enregistrer
default : // Retour au jeu 
}**/

///// TEST FENETRE INSCRIPTION

/**
		Inscription register=new Inscription();
		// Afficher
		register.setVisible(true);


**/

///// TEST QUESTION-DEFINITION

/**

WinDefinition fenDef=new WinDefinition("It is a tool that we use to protect ourselves from the rain.It's made  of plastic and nylon. On Winter, you should always have it with you.","umbrella");  
fenDef.setVisible(true);

**/

//// TEST QUESTION-IMAGE

/**

WinPicture imQuest=new WinPicture("Bligha",new ImageIcon("im1.jpg"),new ImageIcon("im2.jpg"),new ImageIcon("im3.jpg"),new ImageIcon("im4.jpg"),1);
imQuest.setVisible(true);

**/