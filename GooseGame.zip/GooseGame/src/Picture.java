import java.io.Serializable;


public class Picture extends Question implements Serializable{

	public Picture(Partie p) {
		super(p);
		// TODO Auto-generated constructor stub
	}
	public String toString()
	{
		return "Image";
	}

}
