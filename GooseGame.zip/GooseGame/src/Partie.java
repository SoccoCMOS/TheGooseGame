import java.io.Serializable;
import java.util.*;


public class Partie implements Serializable{
	
private int scoreEnCours=0;
private   Joueur joueur;
private  TreeMap<Integer,Case> c=new TreeMap<Integer,Case>();
private   Case[] Cases= new Case[100];
private int caseActu;
private boolean clicked=true;
private int direction=1;
private boolean clicked2=false;
private  String avatar;
public Partie(int dir)
{
	direction=dir;
	genererCaseSpecial();
	int i;
	Fin f=new Fin(this);
	Depart d=new Depart(this);
	Cases[99]=d;
	Cases[0]=f;
	Case cas=new Case(this);
	
}


public String toString()
{
	return "";
}
public void genererCaseSpecial()
{
	int i;
	int actu=(int)(Math.random()*97)+1;
	Bonus b=new Bonus(this);
	Malus m= new Malus(this);
	Question q=new Question(this);
	Definition def=new Definition(this);
	Picture im=new Picture(this);
	Saut s=new Saut(this);
	Case cas=new Case(this);
	for(i=1;i<=5;i++)
	{
		 actu=(int)(Math.random()*94)+1;
		 cas=c.get(actu);
		while(cas != null)
		{
		 actu=(int)(Math.random()*90)+1;
		cas=c.get(actu);}
		b.setNum(actu);
		Cases[actu]=b;
	c.put(actu, b);
	}
	for(i=1;i<=5;i++)
	{
		 actu=(int)(Math.random()*95)+1;
		 cas=c.get(actu);
		while(cas != null)
		{
		 actu=(int)(Math.random()*95)+1;
		cas=c.get(actu);}
		def.setNum(actu);
		Cases[actu]=def;
	c.put(actu, def);
	}
	for(i=1;i<=5;i++)
	{
		 actu=(int)(Math.random()*90)+1;
		 cas=c.get(actu);
		while(cas != null)
		{
		 actu=(int)(Math.random()*90)+1;
		cas=c.get(actu);}
		im.setNum(actu);
		Cases[actu]=im;
	c.put(actu, im);
	}
	for(i=1;i<=5;i++)
	{
		actu=(int)(Math.random()*90)+1;
		 cas=c.get(actu);
		while(cas != null)
		{
			 actu=(int)(Math.random()*90)+1;
			 cas=c.get(actu);}
		s.setNum(actu);
		Cases[actu]=s;

	c.put(actu, s);
	}
	for(i=1;i<=5;i++)
	{
		actu=(int)(Math.random()*93)+4;
		 cas=c.get(actu);
		while(cas != null)
		{
			 actu=(int)(Math.random()*93)+4;
			 cas=c.get(actu);}
		m.setNum(actu);
		Cases[actu]=m;

	c.put(actu, m);
	}

}


	public int getScoreEnCours() {
		return scoreEnCours;
	}

	public void setScoreEnCours(int scoreEnCours) {
		this.scoreEnCours = scoreEnCours;
	}

	
	public Joueur getJoueur() {
		return joueur;
	}

	/**
	 * @param joueur the joueur to set
	 */
	public void setJoueur(Joueur joueur) {
		this.joueur = joueur;
	}


	public int getCaseActu() {
		return caseActu;
	}


	public void setCaseActu(int caseActu) {
		this.caseActu = caseActu;
	}
	
	public void setCases(Case cas,int i)
	{
		this.Cases[i]=cas;
	}
	public Case getCase(int i)
	{
		return this.Cases[i];
	}
	public void setCasep(Partie pp,int i)
	{
		Cases[i].setP(pp);
	}
	
	public static void main(String[] args)
	{
		Partie p= new Partie(1);
		p.genererCaseSpecial();
	}
	public boolean isClicked() {
		return clicked;
	}
	public void setClicked(boolean clicked) {
		this.clicked = clicked;
	}


	public int getDirection() {
		return direction;
	}


	public void setDirection(int direction) {
		this.direction = direction;
	}


	public boolean isClicked2() {
		return clicked2;
	}


	public void setClicked2(boolean clicked2) {
		this.clicked2 = clicked2;
	}


	public String getAvatar() {
		return avatar;
	}


	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
}


