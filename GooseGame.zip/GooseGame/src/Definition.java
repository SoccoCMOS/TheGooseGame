import java.io.Serializable;


public class Definition extends Question implements Serializable {

	public Definition(Partie p) {
		super(p);
		// TODO Auto-generated constructor stub
	}
public String toString()
{
	return "Definition";
}
}
