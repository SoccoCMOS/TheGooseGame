

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.text.MaskFormatter;

public class WinDefinition extends JDialog implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Partie p;
	
	public WinDefinition(){};
	
	public WinDefinition(String d,String w,Partie p)
	{
		this.p=p;
		this.setSize(new Dimension(500,500));
		this.setLocation(400, 100);
		this.setResizable(false);
		this.setTitle("Guess the Word");
		this.getContentPane().setBackground(Color.white);
		this.texteDefinition=d;
		this.word=w;
		initComponent();
		valider.addActionListener(this);
		clear.addActionListener(this);
		pursue.addActionListener(this);
		this.setUndecorated(true);
	}
	
	public void initComponent()
	{
/// 1. Infos 
		infosWindow=new JLabel("GUESS THE WORD ! ",0);
		infosWindow.setPreferredSize(new Dimension(400,50));
		infosWindow.setMinimumSize(new Dimension(400,50));
		infosWindow.setMaximumSize(new Dimension(400,50));
		
		infosWindow.setLocation(10,10);
		infosWindow.setForeground(Color.getHSBColor(57,80,120));
		infosWindow.setFont(new Font("Hobo STD",4,28));
		// Ajout � la fenetre
		this.getContentPane().add(infosWindow,BorderLayout.NORTH);
		
/// 2.Zone d�finition
		zoneDefinition=new JPanel();
		zoneDefinition.setSize(new Dimension(500,150));
		zoneDefinition.setBackground(Color.white);
		
		// Ajout du texte de la d�finition
		JTextArea zoneText=new JTextArea(this.texteDefinition);	// Zone de texte	
		zoneText.setMargin(new Insets(3,10,3,3));
		zoneText.setLineWrap(true);  // pour pouvoir sauter les lignes
		zoneText.setEditable(false);
		
		// Param�trer la zone de texte
		zoneText.setBackground(Color.ORANGE);
		zoneText.setForeground(Color.black);
		zoneText.setFont(new Font("Century Normal",1,14));
		zoneText.setTabSize(10);
		zoneText.setWrapStyleWord(true);  // pour �viter que les mots soitent coup�s d'une ligne � l'autre
		
		// Creer le scrollpane qui va contenir la definition
		definition=new JScrollPane(zoneText);

		// PARAMETRER LE JScrollPane
		definition.setBackground(Color.white);
		definition.setBorder(BorderFactory.createTitledBorder("DEFINITION"));
		definition.setBorder(BorderFactory.createTitledBorder(new TitledBorder(""),"Definition",0,0,new Font("Hobo STD",0,16),Color.orange));
		definition.setPreferredSize(new Dimension(490,120));
		zoneDefinition.add(definition,BorderLayout.CENTER);
		
		// Ajout de la zone d�finition � la fenetre
		definition.add(new JPanel(),this);
		this.getContentPane().add(zoneDefinition);
		
/// 3. Zone r�ponse
		
		// Cr�ation et param�trisation
		zoneReponse=new JPanel();
		zoneReponse.setBorder(BorderFactory.createTitledBorder(new TitledBorder(""),"Answer",0,0,new Font("Hobo STD",0,16),Color.getHSBColor(10, 230, 120)));
		zoneReponse.setPreferredSize(new Dimension(490,280));
		zoneReponse.setBackground(Color.white);
		this.getContentPane().add(zoneReponse,BorderLayout.SOUTH);
		
		// Ajout des composants 
		//Zone saisie
		JPanel zoneSaisie=new JPanel();
		zoneSaisie.setPreferredSize(new Dimension(490,60));
		zoneSaisie.setBackground(Color.white); 
		zoneSaisie.setLayout(new FlowLayout());
		
		// Label explicatif
		
		JLabel explication=new JLabel("What word, of " + word.length() + " letters, does match the definition above ? ");
		explication.setFont(new Font("Times New Roman",1,14));
		explication.setForeground(Color.black);
		// Ajout des champs de saisie
		int nbrChamps=word.length();
		userAnswer=new JTextField[nbrChamps];
		
		for (int i=0; i<nbrChamps;i++)
		{
			userAnswer[i]=new JFormattedTextField(createFormatter("L"));  // Cette instruction formate le champ pour qu'il n'accepte que des lettres (1 lettre par champ)et toutes minuscule
			((JFormattedTextField)userAnswer[i]).setPreferredSize(new Dimension(40,40));
			((JFormattedTextField)userAnswer[i]).setForeground(Color.getHSBColor(10, 230, 120));
			((JFormattedTextField)userAnswer[i]).setBackground(Color.white);
			((JFormattedTextField)userAnswer[i]).setFont(new Font("Times New Roman",1,30));

			zoneSaisie.add(userAnswer[i]);
		}
		zoneSaisie.setLocation(40,40);
		zoneReponse.add(explication,BorderLayout.NORTH);
		zoneReponse.add(zoneSaisie,BorderLayout.SOUTH);	
		
		//Zone validation
		zoneValidation=new JPanel();
		zoneValidation.setLayout(new FlowLayout());
		zoneValidation.setPreferredSize(new Dimension(490,60));
		zoneValidation.setLocation(490,400);
		zoneValidation.setBackground(Color.white);
		
		zoneValidation.setLayout(new FlowLayout());
		
		valider=new JButton("");
		valider.setPreferredSize(new Dimension(50, 46));
		clear=new JButton("");
		clear.setPreferredSize(new Dimension(50, 46));
		
		valider.setForeground(Color.darkGray);
		clear.setForeground(Color.darkGray);
		valider.setBorderPainted(false);
		clear.setBorderPainted(false);
		
		valider.setIcon(new ImageIcon("submit.jpg"));
		clear.setIcon(new ImageIcon("clear.png"));
		valider.setBackground(null);
		clear.setBackground(null);
		
		valider.setCursor(new Cursor(12));
		clear.setCursor(new Cursor(12));
		zoneValidation.add(valider);
		zoneValidation.add(clear);
		zoneReponse.add(zoneValidation);
		
		// Zone appr�ciation
		zoneAppreciation=new JPanel();
		zoneAppreciation.setBackground(Color.white);
		//zoneAppreciation.setLayout(new FlowLayout());
		zoneReponse.add(zoneAppreciation);
		appreciation=new JLabel("");
		pursue=new JButton("Back to Plate");
		appreciation.setHorizontalTextPosition(JLabel.CENTER);
		appreciation.setHorizontalAlignment(JLabel.CENTER);
		zoneAppreciation.add(appreciation,BorderLayout.CENTER);
		//zoneAppreciation.add(pursue);
		
		// Ajout du boouton de retour au plateau
		zoneReponse.add(pursue);
		pursue.setVisible(false);
		pursue.setCursor(new Cursor(12));
		
		appreciation.setPreferredSize(new Dimension(400,40));
		appreciation.setMinimumSize(new Dimension(400,40));
		appreciation.setMaximumSize(new Dimension(400,40));
		
		appreciation.setForeground(Color.GREEN);
		appreciation.setFont(new Font("Brush Script",1,18));
	}
	
	// Setters & Getters
	public String getDefinition() {
		return texteDefinition;
	}

	public void setDefinition(String definition) {
		this.texteDefinition = definition;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}


	public String getTexteDefinition() {
		return texteDefinition;
	}

	public void setTexteDefinition(String texteDefinition) {
		this.texteDefinition = texteDefinition;
	}
	
	
	public boolean isCorrect() {
		return correct;
	}

	public void setCorrect(boolean correct) {
		this.correct = correct;
	}


	// Attributes
	private JLabel infosWindow;
	private JPanel zoneDefinition;
	private JScrollPane definition;
	private JPanel zoneReponse;
	private JPanel zoneValidation;
	private JPanel zoneAppreciation;
	private String texteDefinition="";
	private String word;
	private String response="";
	private JTextField[] userAnswer;
	private JButton valider, clear;
	private boolean correct;
	private JLabel appreciation;
	private JButton pursue;

	// Gestion des �v�nements
	
	public void actionPerformed(ActionEvent ev) {
		if (ev.getSource()==valider)
		{
			trtSubmission();
			// V�rification de la r�ponse et appr�ciation 
			if (response.equalsIgnoreCase(word))  // Si �galit� en ignorant la casse
			{
				correct=true;
			}
			else 
			{
				correct=false;
			}
			
			if (correct)
			{
				appreciation.setForeground(Color.green);
				appreciation.setText("Congratulations! You win 20 points");
				Thread music=new MusiqueFond("Sons/CorrectAnswer.wav",0);
				music.start();
				p.setCaseActu(p.getCaseActu()+4);
				p.setScoreEnCours(p.getScoreEnCours()+20);
			}
			else
			{
				appreciation.setForeground(Color.red);
				appreciation.setText("Wrong Answer ! Solution :"+word);
				Thread music=new MusiqueFond("Sons/BadAnswer.wav",0);
				music.start();
				if(p.getScoreEnCours()-10>=0){
				p.setScoreEnCours(p.getScoreEnCours()-10);}
			}
			pursue.setVisible(true);
			valider.setEnabled(false);
		}
		else if (ev.getSource()==clear)
		{
			trtEffacement();
		}
		else 
		{
			this.setVisible(false);
		}
	}
	
	// Traitement de submission de r�ponse
	
	public void trtSubmission()
	{
		clear.setEnabled(false);
		for(int i=0; i<word.length();i++)
		{
			response=response+userAnswer[i].getText();
			userAnswer[i].setEnabled(false);
		}
	}
	// Traitement d'effacement
	public void trtEffacement()
	{
		for(int i=0; i<word.length();i++)
		{
			userAnswer[i].setText("");
		}
		response="";
	}
	
	// Formatage du champ de saisie
	
	protected MaskFormatter createFormatter(String s) {
	    MaskFormatter formatter = null;
	    try {
	        formatter = new MaskFormatter(s);
	    } catch (java.text.ParseException exc) {
	        System.err.println("formatter is bad: " + exc.getMessage());
	        System.exit(-1);
	    }
	    return formatter;
	}
	
}
