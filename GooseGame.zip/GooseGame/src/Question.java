import java.io.Serializable;


public class Question extends Case implements Serializable{
	public Question(Partie p) {
		super(p);
		// TODO Auto-generated constructor stub
	}

	public void traitement()
	{
	}
	public String toString()
	{
		return "Question";
	}

}
